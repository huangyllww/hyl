import sys 
import __main__
from itpii.datatypes import *
from com.ami.debugger.micommands import MICommandLoadFV,MICommandExpandProtocols,MICommandReboot,MICommandExecStep,MICommandExecContinue,MICommandReboot,MICommandExecInterrupt,MICommandExecContinue,MICommandExecNext,MICommandListRegNames,MICommandDataDisassemble,MICommandStackListFrames,MICommandExecUntil,MICommandSmmEntryBreak,MICommandSmmExitBreak,MICommandIORead,MICommandBreakInsert,MICommandExecStepInstruction,MICommandComputeNvram,MICommandScanPCI
from com.ami.debugger.dbgcommands import DbgCmdExpandProtocols,DbgCmdExpandHandles,DbgCmdListHandles,DbgCmdWriteIIO,DbgCmdReadIIO,DbgCmdReadCpuID,DbgCmdReadMemory,DbgCmdReadMsr,DbgCmdWriteMemory,DbgCmdReadPCI,DbgCmdWritePci,DbgCmdPCIList,DbgCmdCpuInfoSingleReg,DbgCmdSingleLineAsm,DbgCmdWriteMsr,DbgCmdWriteIO,DbgCmdGetTargetState,DbgCmdReadNvramVariable
from com.ami.debugger.breakpoints import BreakpointManager
from com.ami.debugger.uicomm import UICommunicator
from com.ami.debugger.kernel import RegisterSetX86,Kernel,HaltModuleManager,CheckpointManager
from com.ami.debugger.symbolicinfo import SourceInfoProviderMS
from com.ami.debugger import CommandSynchronizer
from com.ami.debugger.kernel import ModuleManager
from com.ami.debugger.targeteventhandlers import TraceMsgHandler,ConsoleRedirector
from com.ami.debugger.transporter import Transport
from datetime import datetime
from java.lang import String 
import time
import inspect as _inspect
import os
global itp
global ami
global itpii
import sys as _sys
ctrlFlag = True
memoryCommandsCtrlFlag=False
breakAll = 0
Delay=0


""" This function is used to know whether target is in running or break state """
def isrunning():
	obj=Kernel.getInstance()
	if(obj.getState()==obj.running):
		return True
	else:
		return False
		
""" This function is used to know whether target is in running or break state """			
def ishalted():
	obj=Kernel.getInstance()
	if(obj.getState()==obj.running):
		return False
	else:
		return True

"""	This function is used to get the current value of SMM entry flag"""		
def isSmmEntry():
	obj=Kernel.getInstance()
	return obj.isSmmEntry()

"""	This function is used to get the current value of SMM exit flag"""		
def isSmmExit():
	obj=Kernel.getInstance()
	return obj.isSmmExit()

"""	This function is used to set and reset SMM entry break """	
def smmentrybreak(val):
	obj = MICommandSmmEntryBreak()
	obj2=Kernel.getInstance()
	obj.entryOn = val
	obj2.setSmmEntry(int(val))
	obj.execute()
'''This function helps to get Instruction mode'''
def useMode():
	if(Kernel.getInstance().getProcMode() == 1):
		return "~use32"
	if(Kernel.getInstance().getProcMode() == 2):
		return "~use64"
"""	This function is used to set and reset SMM exit break """	
def smmexitbreak(val):
	obj = MICommandSmmExitBreak()
	obj2=Kernel.getInstance()
	obj.exitOn = val
	obj2.setSmmExit(int(val))
	obj.execute()
def isinitbreakEnabled():
	obj = Kernel.getInstance()
	return obj.isPeiBpEnabled()
	
def isDXEinitbreakEnabled():
	obj = Kernel.getInstance()
	return obj.isDxeBpEnabled()
	
def setInitBreak(val):
	obj = Kernel.getInstance()
	obj.peiBpEnabled = val
	obj.setPeiBpEnabled(int(val))

def setDXEInitBreak(val):
	obj = Kernel.getInstance()
	obj.dxeBpEnabled = val
	obj.setDxeBpEnabled(int(val))

def getVersion():
	obj = Transport.getInstance()
	if (obj.auth.detectRx() == 0) & ('vid_046b&pid_0980' in obj.bulkUSBName):
		return 'AMIDebugRx Version Number : v3.3.6\\n'
	else:
		return 'AMIDebugRx not connected'
# rectifyValue helps converting hex str values to long (formatcode=0) and long/int to hex string (formatcode=1) 
def rectifyValue(val,formatcode=0):
	if formatcode==0:
		if type(val)==str:
			if val.startswith('0x')==False and val.startswith('0X')==False:
				val='0x'+val
			return long(val,16)
		elif type(val)==int or long:
			return val
	elif formatcode==1:
		if type(val)==str:
			if val.find("0x")==-1:
				val="0x"+val
			return val
		elif type(val)==int or long:
			strval=hex(val)
			if strval.find('L')==-1:
				return strval
			else:
				return strval[0:len(strval)-1]
def getRegisterValue(str,val=0):
	if isrunning() == True:
		print("~cannot execute invd comamnd..........\\n")
		print("~Target is in running state\\n")
		return
	obj=RegisterSetX86.getInstance()
	id=obj.getIDForName_Script(str)
	if val==0:
		temp = format(obj.getVal(id),'x')
		temp = long(temp,16)
	else:
		val=rectifyValue(val)
		obj.setVal(id,val)
	

class ami_class:
	vp = 0
	class Device:
		def __getattr__(self, attr):
			if attr == 'threadid':
				return 0
			if attr=='devicetype':
				return 'Debug RX'
			if attr=='device':
				return 'AMI Debugger'
			if attr=='did':
				var = 0x980
				return var
			if attr=='did':
				return 'vid_046b'
			if attr=='idcode':
				return 'vid_046b'
	devicelist=[]
	for i in range(10) :
		devicelist.append(Device())
	class Addresstype:
		implied=0
		linear=1
		physical=2
		guestphysical=3
		twofieldvirtual=4
		threefieldvirtual=5
		onefieldcodevirtual=6
		onefielddatavirtual=7
		onefieldstackvirtual=8
	class StepType:
		into = 1
		out = 2
		branch = 3
	class flags:
		def __getattr__(self, attr): 
			if attr == 'isrunning':
				return isrunning()
			if attr == 'ishalted':
				return ishalted()
			if attr == 'smmentrybreak':
				return isSmmEntry()
			if attr == 'smmexitbreak':
				return isSmmExit()
			if attr == 'usemode':
				return useMode()
			if attr == 'asmmode':
				return useMode()
			if attr == 'breakall':
				return breakAll
			if attr == 'drprotect':
				return True
			if attr == 'initbreak':
				return isinitbreakEnabled()
			if attr == 'resetbreak':
				return isinitbreakEnabled()
			if attr == 'internalresetbreak':
				return isinitbreakEnabled()
			if attr == 'dxeinitbreak':
				return isDXEinitbreakEnabled()
			if attr == 'targpower':
				return isrunning()
			if attr == 'itpversion':
				return getVersion()
			if attr == 'version':
				return getVersion()
			if attr == 'num_processors':
				return 1
			if attr == 'num_jtag_devices':
				displayString="jtag device count:0"
				_sys.stdout.write(displayString)
				return 0
			if attr=='first_jtag_device':
				displayString="jtag device count:0"
				_sys.stdout.write(displayString)
				return 0
		def __setattr__(self, name, value):
			self.__dict__[name] = value
			if name == 'smmentrybreak':
				smmentrybreak(value)
			if name == 'smmexitbreak':
				smmexitbreak(value)
			if name == 'initbreak':
				setInitBreak(value)
			if name == 'resetbreak':
				setInitBreak(value)
			if name == 'internalresetbreak':
				setInitBreak(value)
			if name == 'dxeinitbreak':
				setDXEInitBreak(value)
			if name == 'breakall':
				if(value==0 or value==1 or value==2):
					global breakAll
					breakAll=value
				else:
					print("~Invalid value\\n")
			del self.__dict__[name]
	cv = flags()
	AddressType=Addresstype()
	class ami_threads:
		vp = 0
		class flags:
			def __getattr__(self, attr): 
				if attr == 'isrunning':
					return isrunning()
				if attr == 'num_processors':
					return 1
		class _state:
			class _regs:
				def __getattr__(self, attr):
					if attr == 'rip' or 'eip':
						val=getRegisterValue('IP')
						return val
					if attr == 'rax' or 'eax':
						val=getRegisterValue('AX')
						return val
					if attr == 'rbx' or 'ebx':
						val=getRegisterValue('BX')
						return val
					if attr == 'rdx' or 'edx':
						val=getRegisterValue('DX')
						return val
					if attr == 'DI':
						val=getRegisterValue('DI')
						return val
					if attr == 'SI':
						val=getRegisterValue('SI')
						return val
					if attr == 'BP':
						val=getRegisterValue('BP')
						return val
					if attr == 'SP':
						val=getRegisterValue('SP')
						return val
					if attr == 'CS':
						val=getRegisterValue('CS')
						return val
					if attr == 'SS':
						val=getRegisterValue('SS')
						return val
					if attr == 'DS':
						val=getRegisterValue('DS')
						return val
					if attr == 'ES':
						val=getRegisterValue('ES')
						return val
					if attr == 'FS':
						val=getRegisterValue('FS')
						return val
					if attr == 'GS':
						val=getRegisterValue('GS')
						return val
					if attr == 'eflags' or 'rflags':
						val=getRegisterValue('Flags')
						return val
					if attr == 'dr0' or 'DR0':
						val=getRegisterValue('DR0')
						return val
					if attr == 'dr1' or 'DR1':
						val=getRegisterValue('DR1')
						return val
					if attr == 'dr2' or 'DR2':
						val=getRegisterValue('DR2')
						return val
					if attr == 'dr3' or 'DR3':
						val=getRegisterValue('DR3')
						return val
					if attr == 'dr4' or 'DR4':
						val=getRegisterValue('DR4')
						return val
					if attr == 'dr5' or 'DR5':
						val=getRegisterValue('DR5')
						return val
					if attr == 'dr6' or 'DR6':
						val=getRegisterValue('DR6')
						return val
					if attr == 'dr7' or 'DR7':
						val=getRegisterValue('DR7')
						return val
					if attr == 'cr0' or 'CR0':
						val=getRegisterValue('CR0')
						return val
					if attr == 'cr1' or 'CR1':
						val=getRegisterValue('CR1')
						return val
					if attr == 'cr2' or 'CR2':
						val=getRegisterValue('CR2')
						return val
					if attr == 'cr3' or 'CR3':
						val=getRegisterValue('CR3')
						return val
					if attr == 'cr4' or 'CR4':
						val=getRegisterValue('CR4')
						return val
				def __setattr__(self, name, value):
					self.__dict__[name] = value
					if name == 'rip' or 'eip':
						getRegisterValue('IP',value)
					if name == 'rax' or 'eax':
						getRegisterValue('AX',value)
					if name == 'rbx' or 'ebx':
						getRegisterValue('BX',value)
					if name == 'rdx' or 'edx':
						getRegisterValue('DX',value)
					if name == 'DI':
						getRegisterValue('DI',value)
					if name == 'SI':
						getRegisterValue('SI',value)
					if name == 'BP':
						getRegisterValue('BP',value)
					if name == 'SP':
						getRegisterValue('SP',value)
					if name == 'CS':
						getRegisterValue('CS',value)
					if name == 'SS':
						getRegisterValue('SS',value)
					if name == 'DS':
						getRegisterValue('DS',value)
					if name == 'ES':
						getRegisterValue('ES',value)
					if name == 'FS':
						getRegisterValue('FS',value)
					if name == 'GS':
						getRegisterValue('GS',value)
					if name == 'eflags' or 'rflags':
						getRegisterValue('Flags',value)
					if name == 'dr0' or 'DR0':
						getRegisterValue('DR0',value)
					if name == 'dr1' or 'DR1':
						getRegisterValue('DR1',value)
					if name == 'dr2' or 'DR2':
						getRegisterValue('DR2',value)
					if name == 'dr3' or 'DR3':
						getRegisterValue('DR3',value)
					if name == 'dr4' or 'DR4':
						getRegisterValue('DR4',value)
					if name == 'dr5' or 'DR5':
						getRegisterValue('DR5',value)
					if name == 'dr6' or 'DR6':
						getRegisterValue('DR6',value)
					if name == 'dr7' or 'DR7':
						getRegisterValue('DR7',value)
					if name == 'cr0' or 'CR0':
						getRegisterValue('CR0',value)
					if name == 'cr1' or 'CR1':
						getRegisterValue('CR1',value)
					if name == 'cr2' or 'CR2':
						getRegisterValue('CR2',value)
					if name == 'cr3' or 'CR3':
						getRegisterValue('CR3',value)
					if name == 'cr4' or 'CR4':
						getRegisterValue('CR4',value)
					del self.__dict__[name]
			regs=_regs()
		state=_state()		
		cv=flags()
	threads = []
	threads.append(ami_threads())
	def printf(self,format,*args):
		format=format.replace("\n","\\n")
		format=format.replace("\t","\\t")
		format=format.replace("\r","\\r")
		format=format.replace('"',' ')
		format='~'+format
		_sys.stdout.write(format %args)
	def invd(self):
		if isrunning() == True:
			print("~cannot execute invd comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		obj=DbgCmdSingleLineAsm(1)
		status=obj.execTarget()
		if(int(status)==1):
			print("~INVD command execution completed successfully\\n")
			return True
		else:
			print("~INVD Command wipouts cache memory, Debugger information in cache memory may wipedout\\n")
			print("~If Debugger Info wipesout, Debugger operations may not work properly\n")
			return False
	def wbinvd(self):
		if isrunning() == True:
			print("~cannot execute wbinvd comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		obj=DbgCmdSingleLineAsm(2)
		status=obj.execTarget()
		if(int(status)==1):
			print("~WBINVD command execution completed successfully\\n")
			return True
		else:
			print("~INVD Command wipouts cache memory, Debugger information in cache memory may wipedout\\n")
			print("~If Debugger Info wipesout, Debugger operations may not work properly\n")
			return True



	def convertBytestoValue(self, bytes):
			i=len(bytes)
			st=""
			while i!=0:
				if bytes[i-1]<0 or bytes[i-1]>255:
					temp=bytes[i-1] & 0xff
					temp=hex(temp)
				else:
					temp=hex(bytes[i-1])
				temp=temp.replace('L', '')
				temp=temp.replace('0x', '')
				temp=temp.zfill(2)
				st=st+temp
				i=i-1
			if not st.startswith('0x'):
				st='0x'+st
			bytes=long(st,16)
			return bytes
	def cpuid_eax(self,eax,ecx=None):
		if isrunning() == True:
			print("~cannot execute cpuid_eax comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		print("~cpuid_eax command\\n")
		if(type(eax)!=str and type(eax)!=long and type(eax)!=int):
			print("~eax type is not valid")
			return
		if(ecx!=None):
			if(type(ecx)!=str and type(ecx)!=long and type(ecx)!=int):
				print("~ecx type is not valid")
				return
		if(type(eax)==str):
			eax=long(eax,16)
		if(type(ecx)==str):
			ecx=long(ecx,16)
		if(eax<0):
			print("~Please provide valid eax info\\n")
			return None
		if(ecx==None):
			ecx=0
		if(ecx!=None):
			if(ecx<0):
				print("~Please provide valid ecx info\\n")
		obj=DbgCmdCpuInfoSingleReg(eax,ecx,1)
		status=obj.execTarget()
		if(int(status)==1):
			print("~ReadCpuInfoSingleReg REQ output\\n")
			bytes=obj.getOutput()
			if(bytes[0]!=0):
				print("~Read Status Failure\\n")
				return BitData(32,0xFFFFFFFF)
			bytes=bytes[1:len(bytes)]
			hex=''
			for b in bytes:
				hex += ('0x%x '%b)
			print("~"+hex+"\\n")
			print("~cpuid_eax command completed successfully\\n")
			bytes=self.convertBytestoValue(bytes)
			return BitData(32,bytes)
		else:
			print("~Unable to get CPUID information\\n")
			return BitData(32,0xFFFFFFFF)
	def cpuid_ebx(self,eax,ecx=None):
		if isrunning() == True:
			print("~cannot execute cpuid_ebx comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		print("~cpuid_ebx\\n")
		if(type(eax)!=str and type(eax)!=long and type(eax)!=int):
			print("~eax type is not valid")
			return
		if(ecx!=None):
			if(type(ecx)!=str and type(ecx)!=long and type(ecx)!=int):
				print("~ecx type is not valid")
				return
		if(type(eax)==str):
			eax=long(eax,16)
		if(type(ecx)==str):
			ecx=long(ecx,16)
		if(eax<0):
			print("~Please provide valid eax info\\n")
			return None
		if(ecx==None):
			ecx=0
		if(ecx!=None):
			if(ecx<0):
				print("~Please provide valid ecx info\\n")
		obj=DbgCmdCpuInfoSingleReg(eax,ecx,2)
		status=obj.execTarget()
		if(int(status)==1):
			print("~ReadCpuInfoSingleReg REQ output\\n")
			bytes=obj.getOutput()
			if(bytes[0]!=0):
				print("~Read Status Failure\\n")
				return None
			bytes=bytes[1:len(bytes)]
			hex=''
			for b in bytes:
				hex += ('0x%x '%b)
			print("~"+hex+"\\n")
			print("~cpuid_ebx command completed successfully\\n")
			bytes=self.convertBytestoValue(bytes)
			return BitData(32,bytes)
		else:
			print("~Unable to get CPUID information\\n")
			return BitData(32,0xFFFFFFFF)
	def cpuid_ecx(self,eax,ecx=None):
		if isrunning() == True:
			print("~cannot execute cpuid_ecx comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		print("~cpuid_ecx\\n")
		if(type(eax)!=str and type(eax)!=long and type(eax)!=int):
			print("~eax type is not valid")
			return
		if(ecx!=None):
			if(type(ecx)!=str and type(ecx)!=long and type(ecx)!=int):
				print("~ecx type is not valid")
				return
		if(type(eax)==str):
			eax=long(eax,16)
		if(type(ecx)==str):
			ecx=long(ecx,16)
		if(eax<0):
			print("~Please provide valid eax info\\n")
			return None
		if(ecx==None):
			ecx=0
		if(ecx!=None):
			if(ecx<0):
				print("~Please provide valid ecx info\\n")
		obj=DbgCmdCpuInfoSingleReg(eax,ecx,3)
		status=obj.execTarget()
		if(int(status)==1):
			print("~ReadCpuInfoSingleReg REQ output\\n")
			bytes=obj.getOutput()
			if(bytes[0]!=0):
				print("~Read Status Failure\\n")
				return None
			bytes=bytes[1:len(bytes)]
			hex=''
			for b in bytes:
				hex += ('0x%x '%b)
			print("~"+hex+"\\n")
			print("~cpuid_ecx command completed successfully\\n")
			bytes=self.convertBytestoValue(bytes)
			return BitData(32,bytes)
		else:
			print("~Unable to get CPUID information\\n")
			return BitData(32,0xFFFFFFFF)
	def cpuid_edx(self,eax,ecx=None):
		if isrunning() == True:
			print("~cannot execute cpuid_edx comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		print("~cpuid_edx\\n")
		print("~cpuid_ebx\\n")
		if(type(eax)!=str and type(eax)!=long and type(eax)!=int):
			print("~eax type is not valid")
			return
		if(ecx!=None):
			if(type(ecx)!=str and type(ecx)!=long and type(ecx)!=int):
				print("~ecx type is not valid")
				return
		if(type(eax)==str):
			eax=long(eax,16)
		if(type(ecx)==str):
			ecx=long(ecx,16)
		if(eax<0):
			print("~Please provide valid eax info\\n")
			return None
		if(ecx==None):
			ecx=0
		if(ecx!=None):
			if(ecx<0):
				print("~Please provide valid ecx info\\n")
		obj=DbgCmdCpuInfoSingleReg(eax,ecx,4)
		status=obj.execTarget()
		if(int(status)==1):
			print("~ReadCpuInfoSingleReg REQ output\\n")
			bytes=obj.getOutput()
			if(bytes[0]!=0):
				print("~Read Status Failure\\n")
				return None
			bytes=bytes[1:len(bytes)]
			hex=''
			for b in bytes:
				hex += ('0x%x '%b)
			print("~"+hex+"\\n")
			print("~cpuid_edx command completed successfully\\n")
			bytes=self.convertBytestoValue(bytes)
			return BitData(32,bytes)
		else:
			print("~Unable to get CPUID information\\n")
			return BitData(32,0xFFFFFFFF)
	'''This function displays all loaded drivers'''
	def ListDrivers(self):
		if isrunning() == True:
			print("~cannot get List of Loaded Drivers.........\\n")
			print("~Target is in running state\\n")
			return
		ModuleManager.getInstance().listLoadedDrivers(None)
		return
	''' Function helps to get details of a driver'''
	def LoadedDriverDetails(self,*args):
		if isrunning() == True:
			print("~cannot get Loaded Driver Details..........\\n")
			print("~Target is in running state\\n")
			return
		if(len(args)==0):
			print("~Driver Name should not be empty")
			return
		for module in args:
			if(type(module)!=str):
				print("~Module name must be string")
				continue
			ModuleManager.getInstance().listLoadedDrivers(module)
		return
	'''This function helps to log associated  file list of a loded driver'''
	def LISTSrcFiles(self,*args):
		if isrunning() == True:
			print("~Cannot get SRCFiles list..........\\n")
			print("~Target is in running state\\n")
			return
		if(len(args)==0):
			print("~Driver Name should not be empty")
			return
		for module in args:
			if(type(module)!=str):
				print("~Module name must be string")
				continue
			ModuleManager.getInstance().LISTSrcFiles(module)
		return
	'''This function logs all local variables in console'''	
	def DisplayLocalVar(self,Name=None):
		if isrunning() == True:
			print("~DisplayLocalVar cannot execute..........\\n")
			print("~Target is in running state\\n")
			return
		if(Name==None):
			obj=SourceInfoProviderMS.getInstance()
			obj.showVarInConsole(None)
		else:
			if type(Name)!=str:
				print("~Please Provide Variable Name in String Format..")
				return
			obj=SourceInfoProviderMS.getInstance()
			obj.showVarInConsole(Name)
	'''Function helps to get value of a local/global variable'''
	def VarGetValue(self,Name):
		if isrunning() == True:
			print("~GetLocalVar cannot execute..........\\n")
			print("~Target is in running state\\n")
			return
		obj=SourceInfoProviderMS.getInstance()
		if(type(Name)!=str):
			print("~Name of the variable must be a string\\n")
			return
		obj.getVarValue(Name)
	'''Function helps to set value of a local/global variable'''
	def VarSetValue(self,Name,Value):
		if isrunning() == True:
			print("~GetLocalVar cannot execute..........\\n")
			print("~Target is in running state\\n")
			return
		obj=SourceInfoProviderMS.getInstance()
		if(type(Name)!=str):
			print("~Name of the variable must be a string\\n")
			return
		Value=rectifyValue(Value,1)
		obj.setVarValue(Name,Value)
	'''This function helps to get Instruction mode'''
	def usemode(self):
		if(Kernel.getInstance().getProcMode() == 1):
			print("~use32\\n")
		if(Kernel.getInstance().getProcMode() == 2):
			print("~use64\\n")
	'''This function helps to get Instruction mode'''
	def usemoderaw(self):
		if(Kernel.getInstance().getProcMode() == 1):
			print("~use32\\n")
			return 1
		if(Kernel.getInstance().getProcMode() == 2):
			print("~use64\\n")
			return 2
	''' This function performs basic timer operation'''		
	def Timer(self):
		if(isrunning()):
			print("~Timer command cannot execute..........\\n")
			print("~Target is in running state\\n")
			return
		print("~Timer operation started\\n")
		obj=obj=BreakpointManager.getInstance()
		obj.timer()
		print("~Timer operation completed\\n")
	''' This function helps to display last breakpoint detection details in console'''	
	def breakdetectionmethod(self):
		type=Kernel.getInstance().getBreakhandledType()
		if(str(type)!=""):
			print("~Last Target Break details\\n")
			print("~"+type)
			return True
		else:
			print("~Not able to display last breakpoint details\\n")
			return False
	''' This function helps to display last breakpoint detection details in console'''	
	def cause(self):
		if isrunning() == True:
			print("~cannot execute cause comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		self.breakdetectionmethod()
	'''The expression to evaluate. If the expression is numerical, then it is converted to binary, decimal,and hexadecimal.
	If the expression is a string and cannot be converted to a number, then the bytes of the string are displayed.
	If the expression contains a floating point value, then the bytes of the floating point value are displayed.'''	
	def eval(self,argument):
		if(type(argument)==int or type(argument)==long):
			value=format(argument,'d')
			print ("~Decimal: "+value+"\\n")
			value=format(argument,'02x')
			print("~Hexadecimal: 0x"+value+"\\n")
			value=format(argument,'o')
			print("~Octal: "+value+"\\n")
			value=format(argument,'b')
			print("~binary: "+value+"\\n")
		if(type(argument)==str):
			try:
				result=int(argument,16)			
				print "~Value of string ",result
				print("~\\n")
			except Exception, e:
				result = map(ord,argument)
				print "~Bytes of the string %s\\n" %result
		if(type(argument)==float):
			st=repr(argument)
			bytearr=st.encode('utf-8')
			result = map(ord,bytearr)
			print "~Bytes of the floating point value%s\\n" %result
			
	
	'''Appends source code for an object into a file.
	
	Arguments:
		filename   -- Name of the file to append to.  Must be enclosed in quotes.
		objectname -- Name of the object to get source for.  Must be enclosed in
						quotes.  See Remarks.
						
		Returns:None.
		
		Remarks:
		Attempts to obtain the source code for the specified object name (which
		can be a module, function, or type but not variable) and, if successful,
		appends the source code to the specified file.
		
		Raises a ValueError if the source code for the specified object cannot be
		obtained.
		
		Raises an IOError if unable to write to file.
		
		Usage:
		>>? def myfunc():
		...     print("Hello!")
		...
		>>? itpii.append("myfunc.py", "myfunc")
		'''	
	def append(self,filename,objectname):
		try:
			source = self._getsource(objectname)
		except Exception, e:
			raise ValueError("Unable to obtain source for '%s': %s" % (objectname, str(e)))
		try:
			file1=open(filename, "a")
			file1.write(source)
			file1.close()
		except Exception, e:
			raise IOError("Unable to append file '%s': %s" % (filename, str(e)))
		print("~apeend command completed successfully\\n")
		return None
		
	'''Get the source code for a named object. Returns a string.
	
	This helper function currently tries 3 approaches (in this order) to obtain
	the source code for the named object:
	1. try to get source using repr(eval(repr(obj)))
	2. try to get source using inspect.getsource()
	3. try to get source from readline command history (interactive only)
	
	It will raise a NameError if the object does not exist in the main
	namespace, and will raise a ValueError if unable to get the source code.'''
	def _getsource(self,objectname):
		sourcestring = ""
		try:
			sourcestring = "%s = %s\n" % (objectname, repr(eval(repr(__main__.__dict__[objectname]))))
		except:
			try:
				sourcestring = _inspect.getsource(eval(objectname, __main__.__dict__))
			except:
				try:
					sourcestring = self._fromhistory(objectname, type(__main__.__dict__[objectname]))
				except:
					raise ValueError("Not found")
		assert sourcestring != ""
		return sourcestring
		
		
	'''Get the source code from command history. Returns a string.
	
	This helper function attempts to extract source code for the object from
	the command history. Note that this is only possible if the readline module
	is available (implicitly raises NameError if not) and the command history
	has been populated (either via interative usage, or a call to the
	readline.read_history_file() function). This function will raise a
	NotImplementedError if object_type is not supported, and a ValueError if
	nothing is found in the command history.'''
	def _fromhistory(self,objectname, object_type):
		sourcestring = ""
		max_index = _readline.get_current_history_length()
		index = max_index - 1
		while index >= 0 and sourcestring == "":
			line = _readline.get_history_item(index).expandtabs() + "\n"
			if object_type == _types.FunctionType:
				regexp = _re.compile("def\s*%s\s*\(" % objectname)
			elif object_type == _types.ClassType:
				regexp = _re.compile("class\s*%s\s*\(" % objectname)
			else:
				raise NotImplementedError("unable to handle type '%s'" % object_type)

			if regexp.match(line):
				sourcestring += line
				findex = index + 1
				nextline = _readline.get_history_item(findex).expandtabs() + "\n"
				leading_space = len(_re.match("(\s*).*", line).group(1))
				while findex <= max_index:
					line = _readline.get_history_item(findex).expandtabs() + "\n"
					if leading_space == len(_re.match("(\s*).*", line).group(1)):
						break
					sourcestring += line
					findex += 1
				try:
					compile(sourcestring + "\n", "<stdin>", "exec")
				except (SyntaxError, IndentationError), e:
					sourcestring = ""

			index -= 1

		if sourcestring == "":
			raise ValueError("Found nothing")
		return sourcestring
	def wait(self,t=None):
		print '~Wait Command\\n'
		if (t!=None) & (t<=0):
			print '~Give valid time\\n'
			return
		Kernel.getInstance().setScriptingmode(True)
		obj=BreakpointManager.getInstance()
		if t==None:
			status = obj.waitForCommandComplete('TargetResponse',0)
		else:
			status = obj.waitForCommandComplete('TargetResponse',t)
		if int(status) == 0:
			print '~Wait command completed\\n'
	


	def memoryscandelay(self,delay):
		if delay < 0:
			print '~Give proper delay in seconds\\n'
			return
		global Delay
		Delay = delay
		print '~Delay of '+str(delay)+' seconds will be given between each memory operation\\n'
		
	def forcememoryscandelay(self,delay):
		if delay < 0:
			print '~Give proper delay in seconds\\n'
			return
		global Delay
		Delay = delay
		print '~Delay of '+str(delay)+' seconds will be given between each memory operation\\n'
		
		
	""" This command is used to get number of active processor """
	def num_processors(self):
		print '~1, Ami debugger supports only BSP processor\\n'
	
	""" This command is used to get the number of running thread """
	def NumberThreads(self):
		print '~1\\n'
	
	"""	This command is used to get number of active processor"""
	def num_activeprocessors(self):
		print '~1, Ami debugger supports only BSP processor\\n'
	
	"""	This command is used to print the current system time """
	def time(self):
		print '~'+datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		print "~\\n"
	
	"""	This command is used to stop the script execution for the specific seconds """
	def sleep(self,sec):
		print '~sleep Starts: '
		self.time()
		time.sleep(sec)
		print '~\\nsleep Ends: '
		self.time()
	
	""" Display the current target state and current phase """
	def status(self):
		obj = DbgCmdGetTargetState()
		success = obj.execTarget()
		if int(success)==0:
			print "~status Command Failed"
			return False
		a = obj.getOutput()
		if(isrunning()):
			print '~Target state : Running\\n'
		else:
			print '~Target state : Halted\\n'
		if a[0] == 0:
			print '~Current Phase : PEI Phase Before MemoryInit\\n'		
		if a[0] == 1:
			print '~Current Phase : PEI Phase After MemoryInit\\n'
		if a[0] == 3:
			print '~Current Phase : DXE Phase\\n'
	
	"""	Display the current target state,current connection details and firmware version of AMIDebugRx"""
	def hwstatus(self):
		if(isrunning()):
			print '~Target state : Running\\n'
		else:
			print '~Target state : Halted\\n'
		obj = Transport.getInstance()
		print '~Current Connection PORT Type : '+ obj.currentPortType+"\\n"
		if (obj.auth.detectRx() == 0) & ('vid_046b&pid_0980' in obj.bulkUSBName):
			print '~Device Connected : AMIDebugRx v3.3.6\\n'
		if (obj.auth.detectRx() == 0) & ('vid_046b&pid_0980' not in obj.bulkUSBName):
			print '~Firmware upgrade required\\n'
		if obj.auth.detectRx() != 0:
			print '~AMIDebugRx not connected \\n'
		
	""" This command is used to log the trace messages in DebugMessageLog.txt file """
	def commands_logging(self):
		print '~Start logging target trace messages in DebugMessageLog.txt file\\n'
		TraceMsgHandler.setFlag(True)
	
	""" This command is used to stop logging the trace messages in DebugMessageLog.txt file """
	def stopdallog(self):
		print '~Stop logging target trace messages in DebugMessageLog.txt file\\n'
		TraceMsgHandler.setFlag(False)

	"""	Helper function for step command """	
	def stepInto(self):
		print("~StepInto command\\n")
		obj=MICommandExecStep()
		if(obj.canExecWhileTargetRunning()==False):
			if(isrunning()):
				print("~Stepinto command cannot execute..........\\n")
				print("~Target is in running state\\n")
				return
		obj.setScriptingFlag(True)
		obj.execute()
		obj.setScriptingFlag(False)
		print("~\\nStepInto command completed successfully\\n")
	
	"""	Helper function for step command """
	def stepOver(self):
		print("~stepOver command\\n")
		obj=MICommandExecNext()
		if(obj.canExecWhileTargetRunning()==False):
			if(isrunning()):
				print("~StepOver command cannot execute..........\\n")
				print("~Target is in running state\\n")
				return
		obj.setScriptingFlag(True)
		obj.execute()
		obj.setScriptingFlag(False)
		print("~\\nStepOver command completed successfully\\n")
		
	"""	Helper function for step command """
	def stepReturn(self):
		print("~stepReturn command\\n")
		obj=MICommandExecUntil()
		if(obj.canExecWhileTargetRunning()==False):
			if(isrunning()):
				print("~StepReturn command cannot execute..........\\n")
				print("~Target is in running state\\n")
				return
		obj.setScriptingFlag(True)
		obj.execute()
		obj.setScriptingFlag(False)
		print("~\\nstepReturn command completed successfully\\n")
		
	"""	Helper function for istep command """
	def instructionStepin(self):
		try:
			print("~Instruction StepInto command\\n")
			obj=MICommandExecStepInstruction()
			if(obj.canExecWhileTargetRunning()==False):
				if(isrunning()):
					print("~Instruction step into command cannot execute..........\\n")
					print("~Target is in running state\\n")
					return
			obj.setScriptingFlag(True)
			obj.execute()
			obj.setScriptingFlag(False)
			print("~\\nInstruction StepInto command completed successfully\\n")
		except TypeError:
			print '~The steps parameter must be an integer'
			
	"""	This command is used to resume the execution and Run to particular address or Line """
	def go(self,address = None):
		if address == None:
			print("~Resume command\\n")
			obj=MICommandExecContinue()
			if(obj.canExecWhileTargetRunning()==False):
				if(isrunning()):
					print("~go command cannot execute..........\\n")
					print("~Target is in running state\\n")
					return
			obj.execute()
			print("~\\nResume command completed successfully\\n")
		else:
			obj1 = MICommandBreakInsert()
			obj1.address_break = True
			obj1.runToCur = True
			obj1.breakAddr = rectifyValue(address)
			obj1.execute()
			obj=MICommandExecContinue()
			if(obj.canExecWhileTargetRunning()==False):
				if(isrunning()):
					print("~go command cannot execute..........\\n")
					print("~Target is in running state\\n")
					return
			obj.setScriptingFlag(True)
			obj.execute()
			obj.setScriptingFlag(False)
	
	""" This command is used to reset the target """
	def pulsepwrgood(self):
		print("~Reset command\\n")
		obj=MICommandReboot()
		obj.setScriptingFlag(True)
		obj.execute()
		obj.setScriptingFlag(False)
	
	"""	This command is used to halt the target from the current execution (Dynamic Break)"""
	def halt(self):
		print("~suspend command\\n")
		obj=MICommandExecInterrupt()
		obj.setScriptingFlag(True)
		obj.execute()	
		obj.setScriptingFlag(False)
		print("~suspend command completed successfully\\n")
			
	"""	This command is used to Perform a single step of program execution """
	
	def step(self,stepType = 1, steps = 1):
		if stepType == 1:
			for index in range(steps):
				self.stepInto()
				"""wait 0.5s for the Debugger core to process other MI command such as read memory and read register"""
				time.sleep(0.5)
		if stepType == 2:
			for index in range(steps):
				self.stepOver()
				time.sleep(0.5)
		if stepType == 3:
			for index in range(steps):
				self.stepReturn()
				time.sleep(0.5)
				
	"""	This command is used to Perform a single step of machine-language instruction """
		
	def istep(self,steps = 1):
		for index in range(steps):
			self.instructionStepin()
	"""	This command is used to resume the execution and Run to particular address or Line """
	def reset(self):
		print("~Reset command\\n")
		obj=MICommandReboot()
		obj.setScriptingFlag(True)
		obj.execute()
		obj.setScriptingFlag(False)
	def halttimeout(self,timeout):
		if(timeout<0):
			print("~Please give valid timeout")
			return
		obj=CommandSynchronizer.getInstance()
		obj.commandTimeoutNotify(timeout)
		halt=MICommandExecInterrupt()
		halt.setTimoutFlag(True)
		halt.execute()
		halt.setTimoutFlag(False)
		obj.commandTimeoutNotify(0)
	'''User can modify retry count of halt action'''
	def num_halt_retries(self,retry=None):
		if(retry==None):
			print("~Number of halt retries "+str(kernel.getInstance().getretrycount()))
			return
		elif(retry<0 or retry==0):
			print("~Please give valid retry count\\n")
		elif(retry==1):
			halt=MICommandExecInterrupt()
			halt.execute()
		else:
			Kernel.getInstance().retrycount(True,retry)
			halt=MICommandExecInterrupt()
			halt.setScriptingFlag(True)
			halt.execute()
			Kernel.getInstance().retrycount(False,retry)
			halt.setScriptingFlag(False)
			print("~Exiting num_halt_retries command\\n")
	'''This command helps to invoke stop debug action'''
	def exit(self):
		print("~Stop Debug invoked\\n")
		Kernel.getInstance().NotifyUIforShutDown()
	'''This command helps to invoke stop debug action'''
	def stopmasterframe(self):
		print("~Stop master frame invoked\\n")
		Kernel.getInstance().NotifyUIforShutDown()
	""" This command helps user unload the loaded symbols"""
	def unloadsymbols(self):
		if isrunning() == True:
			print("~Unload symbols cannot execute..........\\n")
			print("~Target is in running state\\n")
			return
		obj=SourceInfoProviderMS.getInstance()
		obj.clearModuleInfo()
		ModuleManager.getInstance().clearloadedModules()
		print("~unload symbols command completed successfully\\n")
	""" This command is used to display  extended register set in AptioVDebugger console"""
	def xmregs(self):
		if(isrunning()):
			print("~Register set display cannot execute..........\\n")
			print("~Target is in running state\\n")
			return
		if(Kernel.getInstance().getProcMode() == 2):
			RegisterSetX86.getInstance().displayRegistersSet()
		else:
			print("~Not possible to retrieve extended register set in this phase\\n")
			print("~Available register set\\n")
			RegisterSetX86.getInstance().displayRegistersSet()
	
	""" This command is used to display the values of given register names"""
	def display(self,*arg_list):
		if(isrunning()):
			print("~Register set display cannot execute..........\\n")
			print("~Target is in running state\\n")
			return
		count=0;
		if(len(arg_list)==0):
			print("~Display register opration failed. No valid register name has given to display\\n")
			obj=RegisterSetX86.getInstance()
			print("~Available Registers\\n")
			obj.getIDForName_Script('Registers')
			return False
		else:
			for i in arg_list:
				if(type(i)!=str):
					print("~Type of arguments must be string\\n")
					return
			for i in arg_list:
				obj=RegisterSetX86.getInstance()
				id=obj.getIDForName_Script(str(i))
				if(id==-1):
					print("~Register named "+i+" not found\\n")
				else:
					print("~Register "+i+" Value="+format(obj.getVal(id),'x')+"\\n")
					count+=1
		if(count==0):
			print("~Available Registers\\n")
			obj.getIDForName_Script('Registers')
			
	""" This command is used to display  register set in AptioVDebugger console"""
	def regs(self):
		if(isrunning()):
			'''print("~Register set dispaly cannot execute..........\\n")
			print("~Target is in running state\\n")'''
			return False
		obj=RegisterSetX86.getInstance()
		obj.displayRegistersSet()
	""" Helper functio to check Pci is valid or not based on provided BDF"""
	def checkValidPCI(self,bus,dev,fun):
		DEV_DATA_SIZE =0x7;
		req_dev_cnt = 1;
		req_data_size = req_dev_cnt* DEV_DATA_SIZE;
		obj=DbgCmdPCIList(bus,dev,fun,req_dev_cnt,req_data_size)
		status=obj.execTarget()
		if int(status)==0:
			return False
		recieve=[]
		if(obj.GetBlkSize()==0):
			return False
		else:
			bytes=obj.getOutput()
			if(len(bytes)!=7):
				return False
			for byte in bytes: 
				byte=format(byte,'02d')
				recieve.append(byte)
			if(bus!=int(recieve[4]) or dev!=int(recieve[5]) or fun!=int(recieve[6])):
				return False
		return True
		
	""" This function is used to read/write from/into pci configuration space"""
	def pciHelperFunc(self,bytes,size):
		if(len(bytes)!=size):
			return None
		else:
			i=size
			st=""
			while i!=0:
				if bytes[i-1]<0 or bytes[i-1]>255:
					temp=bytes[i-1] & 0xff
					temp=hex(temp)
				else:
					temp=hex(bytes[i-1])
				temp=temp.replace('L', '')
				temp=temp.replace('0x', '')
				temp=temp.zfill(2)
				st=st+temp
				i=i-1
			if not st.startswith('0x'):
				st='0x'+st
			st=long(st,16)
			return st
	""" This function is used to get valid pcidevices """
	def PCIList(self,minbus=0,maxbus=255):
		if isrunning() == True:
			print("~cannot execute PCIList comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		obj=MICommandScanPCI()
		_pciList=obj.scanPCIListCommands(minbus,maxbus)
		return _pciList
	""" This function is used to get valid pci devices count """
	def PCICount(self):
		if isrunning() == True:
			print("~cannot execute PCICount comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		obj=MICommandScanPCI()
		_pciCount=obj.pciCount()
		print("~Available PCI Devices Count %d"%_pciCount)
		return _pciCount
	def pci_configb(self,bus, dev, fun, reg,val=0):
		bus=rectifyValue(bus)
		dev=rectifyValue(dev)
		fun=rectifyValue(fun)
		reg=rectifyValue(reg)
		if(val==0):
			val=self.pci_config(bus,dev,fun,reg,0x01)
			return val
		else:
			val=rectifyValue(val)
			self.pci_config(bus,dev,fun,reg,0x01,val)
	def pci_configw(self,bus, dev, fun, reg,val=0):
		bus=rectifyValue(bus)
		dev=rectifyValue(dev)
		fun=rectifyValue(fun)
		reg=rectifyValue(reg)
		if(val==0):
			val=self.pci_config(bus,dev,fun,reg,0x02)
			return val
		else:
			val=rectifyValue(val)
			self.pci_config(bus,dev,fun,reg,0x02,val)
	def pci_configd(self,bus, dev, fun, reg,val=0):
		bus=rectifyValue(bus)
		dev=rectifyValue(dev)
		fun=rectifyValue(fun)
		reg=rectifyValue(reg)
		if(val==0):
			val=self.pci_config(bus,dev,fun,reg,0x04)
			return val
		else:
			val=rectifyValue(val)
			self.pci_config(bus,dev,fun,reg,0x04,val)
	def pci_configq(self,bus, dev, fun, reg,val=0):
		bus=rectifyValue(bus)
		dev=rectifyValue(dev)
		fun=rectifyValue(fun)
		reg=rectifyValue(reg)
		if(val==0):
			val=self.pci_config(bus,dev,fun,reg,0x08)
			return val
		else:
			val=rectifyValue(val)
			self.pci_config(bus,dev,fun,reg,0x08,val)
	def HandleFailure(self,val,_type):
		if _type==1:
			return BitData(8,val)
		if _type==2:
			return BitData(16,val)
		if _type==4:
			return BitData(32,val)
		if _type==8:
			return BitData(64,val)
		return val
			
	""" This function is used to read/write from/into pci configuration space"""
	def pci_config(self,bus, dev, fun, reg, size=4, val=0):
		if(isrunning()):
			print("~PCI config read/write cannot execute..........\\n")
			print("~Target is in running state\\n")
			return False
		bus=rectifyValue(bus)
		dev=rectifyValue(dev)
		fun=rectifyValue(fun)
		reg=rectifyValue(reg)
		size=rectifyValue(size)
		if(bus<0 or bus>255 or dev<0 or dev>31 or fun<0 or fun>7):
			print("~Please provide valid bus, device, function details\\n")
			return False
		if(reg+size>0XFF) and (reg+size>0xFFF):
			print("~Maximum reasonable offset is 0xff, adjust size accordingly\\n")
			return False
		if(size<=0 or size>255):
			print("~num should be in between 1 and 0xff\\n")
			return False
		if size != 0x1 and size != 0x2 and size != 0x4 and size != 0x8 and size != 0x16:
			print("~INVALID ARGUMENT: num %d is not 1, 2, 4, 8, or 16\\n"%size)
			return False
		if(reg>256 or reg<0):
			print("~offset should be in between 0 to 0xff")
			return False
		if type(bus)!=int and type(bus)!=long:
			bus=int(str(bus),10)
		if type(fun)!=int and type(fun)!=long:
			fun=int(str(fun),10)
		if type(dev)!=int and type(dev)!=long:
			dev=int(str(dev),10)
		if type(reg)!=int and type(reg)!=long:
			reg=int(str(reg),10)
		if type(val)!=int and type(val)!=long:
			val=long(str(val),10)
		status=self.checkValidPCI(bus,dev,fun)
		if int(status)==0:
			i=0
			s=""
			while i<size:
				s=s+'FF'
				i=i+1
			if not s.startswith('0x'):
				s='0x'+s
			val=long(s,16)
			val=self.HandleFailure(val,size)
			return val
		if val == 0:
			#print("~PCI read...\\n")
			obj=DbgCmdReadPCI(bus, dev, fun, reg, size)
			status=obj.execTarget()
			bytes=[]
			if int(status)==0:
				i=0
				s=""
				while i<size:
					s=s+'FF'
					i=i+1
				if not s.startswith('0x'):
					s='0x'+s
				val=long(s,16)
				val=self.HandleFailure(val,size)
				return val
			bytes = obj.getScriptOutput()
			if size==1:
				val=self.pciHelperFunc(bytes,1)
				if(val==None):
					return BitData(8,0xFF)
				return BitData(8,val)
			elif size==2:
				val=self.pciHelperFunc(bytes,2)
				if(val==None):
					return BitData(16,0xFFFF)
				return BitData(16,val)
			elif size==4:
				val=self.pciHelperFunc(bytes,4)
				if(val==None):
					return BitData(32,0xFFFFFFFF)
				return BitData(32,val)
			elif size==8:
				val=self.pciHelperFunc(bytes,8)
				if(val==None):
					return BitData(64,0xFFFFFFFFFFFFFFFF)
				return BitData(64,val)
			else:
				val=self.pciHelperFunc(bytes,16)
				if(val==None):
					return 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFL
				return val
		else:
			#print("~PCI write...\\n")
			val=rectifyValue(val)
			if(size==1):
				if(val>0xff):
					print("~Invalid value provided to pci write\\n")
					return False
			if(size==2):
				if(val>0xffff):
					print("~Invalid value provided to pci write\\n")
					return False
			if(size==4):
				if(val>0xffffffff):
					print("~Invalid value provided to pci write\\n")
					return False
			if(size==8):
				if(val>0xffffffffffffffff):
					print("~Invalid value provided to pci write\\n")
					return False
			array = self.fullByteArray(size,val)
			array.reverse()
			if(len(array)!=size):
				print("~Please provide valid number of byte to write\\n")
				return False
			for vl in array:
				if(vl>255):
					print("~It is not possible to write bytes, please provide the values in between 0-ff\\n")
					return False
			temp=0
			while(temp!=size):
				bytes=[]
				if(size-temp>=4):
					bytes=array[temp:temp+4]
					obj=DbgCmdWritePci(4,reg+temp,bytes,bus,dev,fun)
					status=obj.execTarget()
					if int(status)==0:
						print("~PCI Write Failure...\\n")
						return False
					temp=temp+4
				elif(size-temp>=2):
					bytes=array[temp:temp+4]
					obj=DbgCmdWritePci(2,reg+temp,bytes,bus,dev,fun)
					status=obj.execTarget()
					if int(status)==0:
						print("~PCI Write Failure...\\n")
						return False
					temp=temp+2
				else:
					bytes.append(array[temp])
					obj=DbgCmdWritePci(1,reg+temp,bytes,bus,dev,fun)
					status=obj.execTarget()
					if int(status)==0:
						print("~PCI Write Failure...\\n")
						return False
					temp=temp+1
		print("~PCI configuration command completed\\n")
		
	
	"""	Helper Function to form the array of bytes for mem and memblock command
	"""
	
	def ByteArray(self,string):
		byte = []
		for index in range(0, len(string), 2):
			if (index + 1) < len(string):
				temp = string[index] + string[index + 1]
				if(int(temp, 16)<127):
					byte.append(int(temp, 16))
				else:
					byte.append((256-int(temp, 16))*(-1))
		return byte
	
	"""	Helper Function to form the array of bytes based on datasize received from the memblock command
		dataSize : 1,2 or 4 based on byte,word,DWord
		a : Bytes received from the memblock command
	"""
	
	def fullByteArray(self,dataSize,*a):
		result = []
		for item in a:
			if type(item).__name__ == "list" or type(item).__name__ == "array":
				for i in item:
					i = format(i,'0'+str(dataSize*2)+'x')
					if(len(i)>dataSize*2):
						i = i[:(dataSize*2)]
					getfullarray = self.ByteArray(i)
					for j in getfullarray:
						result.append(j)
			else:
				item = format(item,'0'+str(dataSize*2)+'x')
				if(len(item)>dataSize*2):
					item = item[:(dataSize*2)]
				getfullarray = self.ByteArray(item)
				for item in getfullarray:
					result.append(item)
		return result
		
	""" This command is used to read or write single value (byte,word or double word) to or from the memory
		address  : Base address From where to start reading or writing
		datasize : 1,2 or 4 based on byte,word,DWord
		newValue : bytes to write,none in case of read	
	"""
	def Address(self,_add,typ=None):
		print("~Address calling")
		if type(_add)!=str:
			return hex(_add)
		else:
			return _add
	def convertArraytoList(self,arr):
		lista=[]
		for x in arr:
			lista.append(x)
		return lista
	

	def mem(self,address,dataSize,newValue=None):
		try:
			if isrunning() == True:
				print("~cannot execute mem comamnd..........\\n")
				print("~Target is in running state\\n")
				return
			if (dataSize!=1) & (dataSize!=2) & (dataSize!=4) & (dataSize!=8):
				print "~dataSize cannot be else then 1,2,4 and 8\\n"
				return
			global Delay
			time.sleep(Delay)
			if newValue==None:
			# read memory
				address=rectifyValue(address)
				obj=DbgCmdReadMemory(address,dataSize)
				success = obj.execTarget()
				if int(success)==0:
					i=0
					s=""
					while i<dataSize:
						s=s+'FF'
						i=i+1
					if not s.startswith('0x'):
						s='0x'+s
					val=long(s,16)
					val=self.HandleFailure(val,dataSize)
					return val
				bytes = obj.getScriptOutput()
				'''if dataSize==1:
					return Ord1(bytes[0])
				if dataSize==2:
					return Ord2(bytes[0])
				if dataSize==4:
					return Ord4(bytes[0])
				if dataSize==8:
					return Ord8(bytes[0])'''
				bitDataOutput=BitData(dataSize*8,bytes[0])
			# Log the data in console	
				for byte in bytes: 
					print "~"+format(byte,'0'+str(dataSize*2)+'x')
				print "~\\n"
				return bitDataOutput
			else:
			# write memory
				address=rectifyValue(address)
				newValue = format(newValue,'0'+str(dataSize*2)+'x')
				if(len(newValue)>dataSize*2):
					newValue = newValue[:(dataSize*2)]
				array = self.ByteArray(newValue)
				if len(array)<dataSize:
					print "~Give proper numbers of bytes to write\\n"
					return False
				obj=DbgCmdWriteMemory(address,dataSize,array)
				success = obj.execTarget()
				if int(success)==0:
					print("~Mem Command Failed\\n")
					return False
			# Sending UI update request
				obj.updateUI(address,dataSize,array)
				print "~Bytes Written Successfully\\n"
		
		except TypeError:
			print "~The address must be expressed as a string\\n"
		
	""" This command is used to read or write range of values to or from the memory
		address  : Base address From where to start reading or writing
		addressOrCount : To address or count for number of elements read/write
		datasize : 1,2 or 4 based on byte,word,DWord
		args 	 : bytes to write,none in case of read	
	"""
	
	def memblock(self,address, addressOrCount, dataSize, *args):
		try:
			if isrunning() == True:
				print("~cannot execute port comamnd..........\\n")
				print("~Target is in running state\\n")
				return
			global memoryCommandsCtrlFlag
			if (dataSize!=1) & (dataSize!=2) & (dataSize!=4) & (dataSize!=8):
				print "~dataSize cannot be else then 1,2,4 and 8\\n"
				return None
			if type(addressOrCount).__name__ == "str":	
			# If 'ToAddress' is given
				s1 = rectifyValue(address)
				s2 = rectifyValue(addressOrCount)
				if s2<=s1:
					print '~To address should be more than from address\\n'
					return None
				addressOrCount = (s2-s1)/dataSize		
			global Delay
			time.sleep(Delay)
			if len(args) == 0:
			# read memory block
				address=rectifyValue(address)
				obj=DbgCmdReadMemory(address,addressOrCount,dataSize)
				success = obj.execTarget()
				if int(success)==0:
					i=addressOrCount*dataSize
					st=""
					while i!=0:
						temp='0xFF'
						temp=temp.replace('L', '')
						temp=temp.replace('0x', '')
						temp=temp.zfill(2)
						st=st+temp
						i=i-1
					if not st.startswith('0x'):
						st='0x'+st
					st=long(st,16)
					if memoryCommandsCtrlFlag==True:
						return st
					if(addressOrCount*dataSize==8) or (addressOrCount*dataSize)==16 or (addressOrCount*dataSize)==32 or(addressOrCount*dataSize)==64:
						return BitData(addressOrCount*dataSize,st)
					return BitData(64,st)
			# Log the result in console 	
				#if ctrlFlag == True:
					#for byte in bytes: 
						#print "~"+format(byte,'0'+str(dataSize*2)+'x')+" "
				#print "~\\n"

				#bytes = obj.getScriptOutput()
				bytes = obj.getScriptOutput()
				if memoryCommandsCtrlFlag==True:
					return bytes
				bytes=self.convertArraytoList(bytes)
				return BitData(addressOrCount*dataSize*32,bytes)
			else:
			# write memory block
				address=rectifyValue(address)
				array = self.fullByteArray(dataSize,*args)
				if len(array)< (dataSize*addressOrCount):
					print "~Give proper numbers of bytes to write\\n"
					return None
				obj = DbgCmdWriteMemory(address,dataSize*addressOrCount,array)
				success = obj.execTarget()
				if int(success)==0:
					print("~Memblock Command Failed\\n")
					return None
			# Sending UI update request
				obj.updateUI(address,dataSize*addressOrCount,array)
				if ctrlFlag == True:
					print("~Bytes Written Successfully\\n")
				return True
		except TypeError:
			print "~The address must be expressed as a string\\n"
	
	""" This command is used to Display the contents of a block of memory.
		address  : Base address From where to start
		addressOrCount : To address or count for number of elements read/write
		datasize : 1,2 or 4 based on byte,word,DWord	
	"""
	
	def memdump(self,address, addressOrCount, dataSize):
		global memoryCommandsCtrlFlag
		memoryCommandsCtrlFlag=True
		bytes = self.memblock(address, addressOrCount, dataSize)
		for byte in bytes: 
			print "~"+format(byte,'0'+str(dataSize*2)+'x')+" "
		print "~\\n"
		memoryCommandsCtrlFlag=False
	
	""" This command is used to Save a range of target memory to a host file.
		filename : file where the data is to be stored.
		address  : Address of the first byte to read from.
		addressOrCount : To address or count for number of elements save
		overwrite : flag to control overwriting the host file,By default it will append		
	"""
	
	def memsave(self,filename, address, addressOrCount = None, overwrite = False):
		try:
			global ctrlFlag
			global memoryCommandsCtrlFlag
			ctrlFlag =  False
			memoryCommandsCtrlFlag=True
			bytes = self.memblock(address, addressOrCount, 1)
			if bytes == None:
				print '~memsave command failed\\n'
				memoryCommandsCtrlFlag=False
				return None
		# Opening the file in write or append mode based on the overwrite flag
			if overwrite == False:
				file1 = open(filename,"a")
			else:
				file1 = open(filename,"w")
			for i in range(len(bytes)):
				file1.write(str(bytes[i])+' ')		
			file1.close()
			print("~Memory Dumped in File\\n")
			memoryCommandsCtrlFlag=False
			ctrlFlag =  True
		except IOError:
			print "~file "+filename+" is read only"
			print "~\\n"
		except ValueError:
			print "~The filename or address must be specified"
			print "~\\n"
			
	""" This command is used to fill a range of target memory with the contents of a host file,
		filename : file where the data comes from..
		address  : Address of the first byte to read from.
		addressOrCount : To address or count for number of elements load	
	"""
	
	def memload(self,filename, address, addressOrCount = None):
		try:
			global memoryCommandsCtrlFlag
			global ctrlFlag
			ctrlFlag = False	
			if type(addressOrCount).__name__ == "str":	
			# If 'ToAddress' is given
				s1 = rectifyValue(address)
				s2 = rectifyValue(addressOrCount)
				if s2<=s1:
					print '~To address should be more than from address\\n'
					return False
				addressOrCount = (s2-s1)/1
			# Opening the file in read mode
			file1 = open(filename,"r")
			if os.stat(filename).st_size == 0:
				print '~File is Empty'
				return False
			b = file1.read().split(' ')
			a = []
			if addressOrCount >= len(b):
				count = addressOrCount
				while count > 0:
					if count > len(b)-1:
						a = a+b[:len(b)-1]
						count = count-len(b)+1
					else:
						a = a+b[:count]
						count = count-len(b)+1
			else:
				a=b[:addressOrCount]
			for i in range(len(a)):
				a[i] = int(a[i])	
			memoryCommandsCtrlFlag=True
			if ami.memblock(address,addressOrCount,1,a) == None:
				print "~Memory load command failed\\n"
				ctrlFlag = True
				memoryCommandsCtrlFlag=False
				return False
			print '~Memory loaded from the file\\n'
			memoryCommandsCtrlFlag=False
			ctrlFlag = True
		except IOError:
			print "~Cannot find file:", filename
			print "~\\n"
		except ValueError:
			print "~The filename or address must be specified", filename
			print '~\\n'
	
	"""	This command is used to save contents of selected portions of target memory to a host file.
		filename : Filename of the object file where the information is stored.
		address  : Address of the first byte to read from.
		addressOrCount : To address or count for number of elements save
		overwrite : True if to overwrite the file if it exists; otherwise, an error is raised.
	"""
	def upload(self,filename, address, addressOrCount = None, overwrite = None):
		try:
			global ctrlFlag
			global memoryCommandsCtrlFlag
			ctrlFlag =  False
			memoryCommandsCtrlFlag=True=True
			bytes = self.memblock(address, addressOrCount, 1)
		# Opening the file in write or append mode based on the overwrite flag
			if (overwrite == False or overwrite == None) and os.path.exists(filename) == True:
				print '~File already present cannnot overwrite the file\\n'
				memoryCommandsCtrlFlag=False
				return
			else:
				file1 = open(filename,"w")
			for i in range(len(bytes)):
				file1.write(str(bytes[i])+' ')		
			file1.close()
			print("~Memory Dumped in File\\n")
			memoryCommandsCtrlFlag=False
			ctrlFlag =  True
		except IOError:
			print "~file "+filename+" is read only"
			print "~\\n"
		except ValueError:
			print "~The filename or address must be specified", filename
			print "~\\n"
	
	""" This command is used to read MSR register value from the target
		address : Address for which MSR value is required
	"""
	
	def msr(self,address, newValue = None):
		print("~MSR Read")
		if isrunning() == True:
			print("~cannot execute msr comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		address=rectifyValue(address)
		obj=DbgCmdReadMsr(address)
		status = obj.execTarget()
		if int(status) == 0:
			print("~msr Command Failed\\n")
			return Ord8(0xFFFFFFFFFFFFFFFF)
		msrValue = obj.getOutputInLong()
	# Check for invalid msr value	
		if msrValue == "Invalid":
			print "~Invalid MSR\\n"
			return
		if newValue == None:
		# Reading MSR Value
			msrValueLong = long(msrValue,16)			
			#print "~Msr value is "+ msrValue
			#print "~\\n"
			return Ord8(msrValueLong)
		else:
		# Changing MSR value
			newValue=rectifyValue(newValue)
			obj = DbgCmdWriteMsr((hex(newValue))[2:],address)
			success = obj.readOnlyCheck((hex(address))[2:])
			if int(success)==1:
				print "~MSR is read only\\n"
				return False
			success = obj.execTarget()
			if int(success)==0:
				print("~msr Command Failed\\n")
				return False
			obj=DbgCmdReadMsr(address)
			status = obj.execTarget()
			if int(status) == 0:
				print("~msr Command Failed\\n")
				return False
			msrValue = obj.getOutputInLong()
			if long(msrValue,16) == newValue:
				print '~MSR value updated successfully\\n'
			else:
				print '~MSR value is not updated\\n'
	
	def validateMSR(self,arg):
		obj=DbgCmdReadMsr(arg)
		status = obj.execTarget()
		if int(status) == 0:
			print("~msr Command Failed\\n")
			return False
		msrValue = obj.getOutputInLong()
		if msrValue == "Invalid":
			print "~Invalid MSR\\n"
			return
		else:
			print '~Valid MSR\\n'
	""" This command is used to Retrieve or change the contents of an 8-bit IA32 I/O port. 
	"""
	def port(self,portNumber, newValue = None):
		if isrunning() == True:
			print("~cannot execute port comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		portNumber=rectifyValue(portNumber)
		if newValue==None:
		# read 8 bits from the port
			obj = MICommandIORead()
			success = obj.readio(portNumber,1)
			if success==None or int(success)==0:
				print "~Port command failed\\n"
				return BitData(8,0xFF)
			bytes = obj.getScriptOutput()	
		# Log the data in console	
			for byte in bytes: 
				print "~"+format(byte,'02x')
			print "~\\n"
			return BitData(8,byte)
		else:
		# writing 8 bits to specified port
			newValue=rectifyValue(newValue)
			if newValue>255:
				print '~The value is larger than 8 bits\\n'
				return None
			array = self.ByteArray(format(newValue,'02x'))
			obj = DbgCmdWriteIO(1,portNumber,1,array[0])
		  #	Check for invalid range
			isValid  = obj.validInfoFromINI(portNumber,1)
			if int(isValid) == 0:
				print '~Given Address falls in invalid range\\n'
				return
		  #	Check for readonly range	
			isReadOnly = obj.readOnlyInfoFromIni(portNumber,1)
			if int(isReadOnly) == 1:
				print '~Given Address falls in Read Only range\\n'
				return
			success = obj.execTarget()
			if int(success)==0:
				print("~port Command Failed\\n")
				return False
			print '~IO port updated successfully\\n'
			
	"""	This command is used to Retrieve or change the contents of a 16-bit IA32 I/O port.
	"""	
	def wport(self,portNumber, newValue = None):
		if isrunning() == True:
			print("~cannot execute wport comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		portNumber=rectifyValue(portNumber)
		if newValue==None:
		# read 16 bits from the port
			obj = MICommandIORead()
			success = obj.readio(portNumber,2)
			if int(success)==0:
				print "~Port command failed\\n"
				return BitData(16,0xFFFF)
			bytes = obj.getScriptOutput()
		# Log the data in console	
			for byte in bytes: 
				print "~"+format(byte,'04x')
			print "~\\n"
			return BitData(16,byte)
		else:
		# writing 16 bits to specified port
			newValue=rectifyValue(newValue)
			if newValue>65535:
				print '~The value is larger than 16 bits\\n'
				return None
			revArray = self.ByteArray(format(newValue,'04x'))
			array = []
			for i in reversed(revArray):
				array.append(i)
			for i in range(2):
				obj = DbgCmdWriteIO(1,portNumber+i,1,array[i])
			  #	Check for invalid range
				isValid  = obj.validInfoFromINI(portNumber,2)
				if int(isValid) == 0:
					print '~Given Address falls in invalid range\\n'
					return
			  #	Check for readonly range
				isReadOnly = obj.readOnlyInfoFromIni(portNumber,2)
				if int(isReadOnly) == 1:
					print '~Given Address falls in Read Only range\\n'
					return
				success = obj.execTarget()
				if int(success)==0:
					print("~port Command Failed\\n")
					return False
			print '~IO port updated successfully\\n'	

	"""	This command is used to Retrieve or change the contents of a 32-bit IA32 I/O port.
	"""	
	def dport(self,portNumber, newValue = None):
		if isrunning() == True:
			print("~cannot execute dport comamnd..........\\n")
			print("~Target is in running state\\n")
			return
		portNumber=rectifyValue(portNumber)
		if newValue==None:
		# read 32 bits from the port
			portNumber=rectifyValue(portNumber)
			obj = MICommandIORead()
			success = obj.readio(portNumber,4)
			if int(success)==0:
				print "~Port command failed\\n"
				return BitData(32,0xFFFFFFFF)
			bytes = obj.getScriptOutput()
		# Log the data in console	
			for byte in bytes: 
				print "~"+format(byte,'08x')
			print "~\\n"
			return BitData(32,byte)
		else:
		# writing 32 bits to specified port
			newValue=rectifyValue(newValue)
			if newValue>2147483647:
				print '~The value is larger than 32 bits\\n'
				return None
			revArray = self.ByteArray(format(newValue,'08x'))
			array = []
			for i in reversed(revArray):
				array.append(i)
			for i in range(4):
				obj = DbgCmdWriteIO(1,portNumber+i,1,array[i])
			  #	Check for invalid range
				isValid  = obj.validInfoFromINI(portNumber,4)
				if int(isValid) == 0:
					print '~Given Address falls in invalid range\\n'
					return
			  #	Check for readonly range
				isReadOnly = obj.readOnlyInfoFromIni(portNumber,4)
				if int(isReadOnly) == 1:
					print '~Given Address falls in Read Only range\\n'
					return
				success = obj.execTarget()
				if int(success)==0:
					print("~port Command Failed\\n")
					return False
			print '~IO port updated successfully\\n'
	'''Listing all available NVRAM variables'''
	def NVRAMList(self):
		if(isrunning()):
			print("~Cannot get NVRAM List..........\\n")
			print("~Target is in running state\\n")
			return False
		nvram=MICommandComputeNvram()
		nvram.showNVRAMDataINConsole()
	'''Getting details of NVRAM variable'''
	def ReadNVRAMVar(self,name,guid):
		if(isrunning()):
			print("~Cannot execute ReadNVRAMVar..........\\n")
			print("~Target is in running state\\n")
			return False
		if(type(name)!=str or type(guid)!=str):
			print("~Name and Guid must be in string format\\n")
			return False
		obj=DbgCmdReadNvramVariable(name,guid)
		status=obj.execTarget()
		if(status==False):
			return False
		else:
			bytes=obj.getScriptOutput()
			if(bytes==None):
				return False
			print("~details of NVRAM variable: "+name+"\\n")
			i=0
			for byte in bytes: 
				i+=1
				print("~"+format(byte,'02x')+" ")
				if i%15==0:
					print("~\\n")
			print("~\\n")
		return True
	'''This function removes all inspection points asscoiated with the breakpoint'''
	def RemoveInspOption(self,id):
		if(isrunning()):
			print("~Cannot RemoveInspOption..........\\n")
			print("~Target is in running state\\n")
			return False
		if(type(id)!=int):
			print("~Breakpoint id must be the first argument\\n")
			print("~Breakpoint type is not integer\\n")
			return False
		if(BreakpointManager.getInstance().isBreakpointExist(id)==False):
			print("~Breakpoint id is not valid\\n")
			return False
		BreakpointManager.getInstance().notifyRemoveInspectionPoint(id)
		return True
	'''This function helps to add inspection point for an existing breakpoint'''
	def AddInspOption(self,*args):
		if(isrunning()):
			print("~Cannot add inspection option..........\\n")
			print("~Target is in running state\\n")
			return
		if(len(args)<2):
			print("~Please give breakpoint id, and type of inspection point\\n")
			return
		if(type(args[0])!=int):
			print("~Breakpoint id must be the first argument\\n")
			print("~Breakpoint type is not integer\\n")
			return
		if(BreakpointManager.getInstance().isBreakpointExist(args[0])==False):
			return False
		if(args[1]=="pci"):
			print("~Inspection point type is pci\\n")
			if(len(args)<7):
				print("~PCI BDF, Configuration space range expected\\n")
				return
			bus=args[2]
			dev=args[3]
			fun=args[4]
			reg=args[5]
			size=args[6]
			if(bus<0 or bus>255 or dev<0 or dev>31 or fun<0 or fun>7):
				print("~Please provide valid bus, device, function details\\n")
				return False
			if(reg+size>255):
				print("~Maximum reasonable offset is 0xff, adjust size accordingly\\n")
				return False
			if(size<=0 or size>255):
				print("~Length should be in between 1 and 0xff\n")
				return False
			if(reg>256 or reg<0):
				print("~offset should be in between 0 to 0xff")
				return False
			BreakpointManager.getInstance().notifyAddInspectionPoint("BreakpointID-"+str(args[0])+";"+"@inspectiondetail;"+"#id-0"+";#pci-"+str(args[2])+"-"+str(args[3])+"-"+str(args[4])+"-"+str(args[5])+"-"+str(args[6]))
			return
		elif(args[1]=="io"):
			print("~Inspection point type is io\\n")
			if(len(args)<4):
				print("~Io address and size expected\\n")
				return
			if(args[3]>255):
				print("~Size should not be greater than 255\\n")
				return
			BreakpointManager.getInstance().notifyAddInspectionPoint("BreakpointID-"+str(args[0])+";"+"@inspectiondetail;"+"#id-0"+";#io-"+str(args[2])+"-"+str(args[3]))
			return
		if(args[1]=="reg"):
			print("~Inspection point type is reg\\n")
			if(len(args)!=2):
				print("~Inspection point type registers does not need any arguments\\n")
			BreakpointManager.getInstance().notifyAddInspectionPoint("BreakpointID-"+str(args[0])+";"+"@inspectiondetail;"+"#id-0"+";#reg-set")
			return
		if(args[1]=="mem"):
			if(len(args)<4):
				print("~Memory address and size expected\\n")
				return
			print("~Inspection point type is mem\\n")
			BreakpointManager.getInstance().notifyAddInspectionPoint("BreakpointID-"+str(args[0])+";"+"@inspectiondetail;"+"#id-0"+";#mem-"+str(args[2])+"-"+str(args[3]))
			return
		if(args[1]=="vars"):
			print("~Inspection point type is vars\\n")
			i=2;
			var=""
			if(len(args)<2):
				print("~No valid variable names given\\n")
				return
			i=3;
			while(i<len(args)):
				if(type(i)!=str):
					print("~Please give variables in string format\\n")
					return
				i=i+1
			i=2
			while(i<len(args)):
				var=var+"-"+args[i]
				i=i+1
			BreakpointManager.getInstance().notifyAddInspectionPoint("BreakpointID-"+str(args[0])+";"+"@inspectiondetail;"+"#id-0"+";#vars"+var)
			return
		else:
			print("~Inspection point type must be one among the following\\n")
			print("~pci\\n")
			print("~io\\n")
			print("~mem\\n")
			print("~reg\\n")
			print("~vars\\n")
			return
	""" This function helps user to observe the available breakpoints and their in console"""
	def br(self):
		if(isrunning()):
			print("~Displaying breakpoint list..........\\n")
			print("~Target is in running state\\n")
			return
		obj=BreakpointManager.getInstance()
		obj.displayBreakpointList()
		
	""" This function helps user to remove breakpoints by id"""	
	def brremove(self,*id):
		print("~breakpoint remove command\\n")
		if(isrunning()):
			print("~Breakpoint remove not possible..........\\n")
			print("~Target is in running state")
			return False
		if(len(id)==0):
			print("~Please give breakpoint id\\n")
			return False
		for item in id:
			obj=BreakpointManager.getInstance()
			obj.removeBreakpoint(item)
	
	""" This function helps user to disable breakpoints by id"""
	def brdisable(self,*id):
		print("~breakpoint disable command\\n")
		if(isrunning()):
			print("~Breakpoint disable not possible..........\\n")
			print("~Target is in running state\\n")
			return False
		if(len(id)==0):
			print("~Please give breakpoint id\\n")
			return False
		for item in id:
			obj=BreakpointManager.getInstance()
			obj.notifyDisableBreakpoint(item)
			
	""" This function helps user to eanble breakpoints by id"""
	def brenable(self,*id):
		print("~breakpoint enable command\\n")
		if(isrunning()):
			print("~Breakpoint enable not possible..........\\n")
			print("~Target is in running state\\n")
			return False
		if(len(id)==0):
			print("~Please give breakpoint id\\n")
			return False
		for item in id:
			obj=BreakpointManager.getInstance()
			obj.notifyEnableBreakpoint(item)
			
	""" This function helps user to get details of breakpoints by id"""
	def brget(self,*id):
		if(isrunning()):
			print("~Breakpoint get not possible..........\\n")
			print("~Target is in running state\\n")
			return False
		if(len(id)==0):
			print("~Please give breakpoint id\\n")
			return False
		for item in id:
			obj=BreakpointManager.getInstance()
			status=obj.getBreakpoint(item)
			return status
	'''Adding a hardware breakpoint on ioread'''	
	def BPonIORead(self,add,size=1):
		if(isrunning()):
			print("~Cannot execute BPonIORead...........\\n")
			print("~Target is in running state\\n")
			return False
		add=rectifyValue(add,1)
		self.brnew(add,'ioread',size)
	'''Adding a hardware breakpoint on iowrite'''
	def BPonIOWrite(self,add,size=1):
		if(isrunning()):
			print("~Cannot execute BPonIOWrite.........\\n")
			print("~Target is in running state\\n")
			return False
		add=rectifyValue(add,1)
		self.brnew(add,'iowrite',size)
	'''Adding a hardware breakpoint on exec'''
	def BPonExec(self,add,size=1):
		if(isrunning()):
			print("~Cannot execute BPonExec...........\\n")
			print("~Target is in running state\\n")
			return False
		add=rectifyValue(add,1)
		self.brnew(add,'exec',size)
	'''Adding a hardware breakpoint on data write'''
	def BPonDataWrite(self,add,size=1):
		if(isrunning()):
			print("~Cannot execute BPonDataWrite..........\\n")
			print("~Target is in running state\\n")
			return False
		add=rectifyValue(add,1)
		self.brnew(add,'datawrite',size)
	'''Adding a hardware breakpoint on DataReadWriteNoExec'''
	def BPonDataReadWriteNoExec(self,add,size=1):
		if(isrunning()):
			print("~Cannot execute BPonDataReadWriteNoExec.........\\n")
			print("~Target is in running state\\n")
			return False
		add=rectifyValue(add,1)
		self.brnew(add,'noexec',size)
	""" This function helps user to create sw/hw breakpoint"""
	def brnew(self,*args):
		print("~breakpoint create command\\n")
		if isrunning() == True:
			print("~Breakpoint create not possible..........\\n")
			print("~Target is in running state\\n")
			return
		arg_len=len(args)
		enable=None
		if(args[arg_len-1]==True):
			enable=True
		if(args[arg_len-1]==False):
			enable=False
		if(enable!=None):
			args=args[0:arg_len-1]
		else:
			enable=True
		addr=args[0]
		addr=rectifyValue(addr,1)
		if len(args)==1:
			if type(addr)==str:
				if "\\" not in addr:
					obj=BreakpointManager.getInstance()
					obj.notifyAddBreakpoint(addr,"SW",0)
		if len(args)==2:
			if type(addr)==str and type(args[1])==int:
				if "\\" in addr:
					obj=BreakpointManager.getInstance()
					addr=addr.replace('0x', '')
					obj.notifyLineBreakpoint(addr,args[1])
		if len(args)==2:
			hw_type='Invalid'
			if type(addr)==str and type(args[1])==str:
				if "\\" not in addr:
					if args[1]=='exec' or args[1]=='ioread' or args[1]=='iowrite' or args[1]=='datawrite' or args[1]=='noexec':
						obj=BreakpointManager.getInstance()
						obj.notifyAddBreakpoint(addr,args[1],1)
					else:
						print("~Breakpoint type is not valid\\n")
		if len(args)==3:
			hw_type='Invalid'
			if type(addr)==str and type(args[1])==str and type(args[2]==int):
				if "\\" not in args[0]:
					if args[2]!=1 and args[2]!=2 and args[2]!=4:
						print("~Invalid size")
						return
					if args[1]=='exec' or args[1]=='ioread' or args[1]=='iowrite' or args[1]=='datawrite' or args[1]=='noexec':
						obj=BreakpointManager.getInstance()
						obj.notifyAddBreakpoint(addr,args[1],int(args[2]))	
					else:
						print("~Not valid type")

	''' This command helps to display the assembly instruction'''
	def asm(self,address,*args):
		if(isrunning()):
			print("~Target is in running state\\n")
			return
		Kernel.getInstance().setScriptingmode(True)
		diss=MICommandDataDisassemble()
		if(len(args)==0 and address=="$"):
			diss.dissassemblyFromCurrentIP()
			Kernel.getInstance().setScriptingmode(False)
			return
		elif(len(args)==0 and type(address)==str):
			diss=diss.displayDisassembleInstructions(rectifyValue(address),1)
			Kernel.getInstance().setScriptingmode(False)
			return
		elif(len(args)==0 and type(address)!=str):
			diss=diss.displayDisassembleInstructions(address,1)
			Kernel.getInstance().setScriptingmode(False)
		elif(len(args)==1 and type(address)==str and type(args[0])==int):
			diss=diss.displayDisassembleInstructions(rectifyValue(address),args[0])
			Kernel.getInstance().setScriptingmode(False)
			return
		elif(len(args)==1 and type(address)==str and type(args[0])==str):
			start=long(address,16)
			end=long(args[0],16)
			if(start>=end):
				print("~end address should be greater than start address\\n")
				Kernel.getInstance().setScriptingmode(False)
				return
			else:
				diss=diss.displayDisassembleInstructions(start,end-start)
				Kernel.getInstance().setScriptingmode(False)
				return
		else:
			print("~Please provide valid number of/type of arguments\\n")
			Kernel.getInstance().setScriptingmode(False)
	def valueofCurrentInstruction(self):
		obj=RegisterSetX86.getInstance()
		id=obj.getIDForName_Script("IP")
		if(id==-1):
			return 0
		val=obj.getVal(id)
		return val
	""" This command helps user to observe the details of call stack in APtioVDebugger console"""	
	def calls(self):
		if(isrunning()):
			print("~Target is in running state\\n")
			return
		obj=MICommandStackListFrames()
		obj.stackFrameDetails()
		
	"""	This command is used to View or change a range of bits in a value. 
		It Can also be used for in-place changes of BitData and AMI Data Types and
		Register values
		
		object : It can be A valid register name expressed as a string, an arbitrary integer, 
				 or a BitData object or newly created AMI datatypes
		offset : A valid expression yielding the bit index into the specified value
				 This value must be less than the size of the register, integer, or BitData object
		size   : A valid expression yielding the size, in bits, of the bit field. 
				 The size plus the offset must be less than the size of the register, integer, or BitData object.
		new	   : If specified, a numerical value to be assigned to the bit field. 
				 This expression, if it results in a value greater than possible in the bit field, will be truncated to the bit-size during assignment.		
	"""
	
	def bits(self,object,offset,size,new=None):
		obj = None
		val = object
		isObj = False
		length = 0
		s = ""
		
		if (size <= 0):
			print '~Size should be greater than zero\\n'
			return
		if (type(val) == str):
		# Register value access
			obj=RegisterSetX86.getInstance()
			id=obj.getIDForName_Script(val)
			if(id==-1):
				print("~Register named "+val+" not found\\n")
			else:
				val = format(obj.getVal(id),'x')
				val = long(val,16)
			if(Kernel.getInstance().getProcMode() == 1):
				length = 8
			else:
				length = 16		
				
		elif (type(val) == Ord1) | (type(val) == Int1):
			isObj = True
			length = 2
		elif (type(val) == Ord2) | (type(val) == Int2):
			isObj = True
			length = 4
		elif (type(val) == Ord4) | (type(val) == Int4):
			isObj = True
			length = 8
		elif (type(val) == Ord8) | (type(val) == Int8):
			isObj = True
			length = 16
		elif (type(val) == BitData):
			isObj = True
			length = val.length()
		else:
			if length == 0:
				if(type(val)==hex):
					length=len(val)
				else:
					if(type(val)==hex):
						length = len(hex(val).replace("L","")[2:])
		if (type(val)== BitData) and (type(val.getValue())==list):
			val=val.copy(offset,size)
			return val
		if(type(val)!=hex):
			val = hex(val).replace("L","")[2:]

		bits = length*4
		if (offset > bits) | ((offset+size)>bits):
			print("~ValueError : The bit-field must fit within the specified object\\n")
			return
		for i in reversed(range(len(val))):
			s = s+bin(long(val[i],16))[2:].zfill(4)
		
		while(len(s)!=bits):
			s=s+'0'
		
		s1 = s[offset:(offset+size)]
		
		if new == None:
		# If value to assign is not given
			#print "~0x"+(hex(long(s1,2)).replace("L","")[2:])[::-1]
			#print "~\\n"
			val=long((hex(long(s1,2)).replace("L","")[2:])[::-1],16)
			return BitData(64,val)
		if new != None:
		# If value to assign is given
			rs = ""
			new = hex(new).replace("L","")[2:]
			cnt = 0
			for i in reversed(range(len(new))):
				rs = rs+bin(long(new[i],16))[2:].zfill(4)
			if len(rs)<size:
				while(len(rs)!=size):
					rs=rs+'0'
			if len(rs)>size:
				rs = rs[:size]
			a = s[0:offset]
			b = s[offset+size:]
			res = a + rs + b
			res =(hex(long(res,2)).replace("L","")[2:])[::-1]
			if len(res)<length:
				while(len(res)!=length):
					res=res+'0'
			#print "~0x"+res+"\\n"
			
		# If register is given then update its value
			if obj != None:
				obj.setVal(id,long(res,16))	
		# If any class object(IntX,OrdX,BitData) is given then update its value
			if isObj == True:
				object.value=long(res,16)
			val=long(res,16)
			return BitData(64,val)
	
	"""	This command is used to get and alter the value of the particular register
		val : reg name
		newVal : value to update
	"""
	
	def reg(self,val,newVal=None):
		if(isrunning()):
			print("~Register set dispaly cannot execute..........\\n")
			print("~Target is in running state\\n")
			return False
		obj=RegisterSetX86.getInstance()
		id=obj.getIDForName_Script(val)
		if(id==-1):
			print("~Register named "+val+" not found\\n")
			return False	
		if(newVal == None):
			val = format(obj.getVal(id),'x')
			val = long(val,16)
			return val
		else:
			if newVal < 0:
				print '~Register wrtie value should not be negative\\n'
				return False
			newVal=rectifyValue(newVal)
			obj.setVal(id,newVal)
			val = format(obj.getVal(id),'x')
			val = rectifyValue(val)
			return val
	def cpuInfo(self):
		if(isrunning()):
			print("~CpuInfo can't execute..........\\n")
			print("~Target is in running state\\n")
			return False
		obj = DbgCmdReadCpuID()
		success = obj.execTarget()
		if int(success)==0:
			print "~CPUInfo Command Failed\\n"
			return False
		obj.getCpuInfo()
	def cpuDump(self):
		if(isrunning()):
			print("~CpuInfo can't execute..........\\n")
			print("~Target is in running state\\n")
			return False
		obj = DbgCmdReadCpuID()
		success = obj.execTarget()
		if int(success)==0:
			print "~CPUInfo Command Failed\\n"
			return False
		return obj.getOutput()
	"""	This command is used to set halt at particular module entry point.
	"""
	def setHaltDriver(self,arg):
		if(isrunning()):
			print("~Halt at driver can't be set.........\\n")
			print("~Target is in running state\\n")
			return False
		if arg == "":
			print '~Give proper input\\n'
			return False
		obj = HaltModuleManager.getInstance()
		obj.addHaltModule(arg)
		print '~Halt at driver : %s successfully set \\n'%arg
		
	"""	This command is used to remove halt at particular module entry point.
	"""
	
	def removeHaltDriver(self,arg):
		if(isrunning()):
			print("~Halt at driver can't be clear.........\\n")
			print("~Target is in running state\\n")
			return False
		if arg == "":
			print '~Give proper input\\n'
			return False
		obj = HaltModuleManager.getInstance()
		status = obj.removeHaltModule(arg)
		if int(status)==0:
			print "~Requested module is not available in the list\\n"
			return False
		print '~Halt at driver %s successfully removed \\n'%arg
		
	"""	This command is used to set halt at particular checkpoint.
	"""	
	def setHaltCheckpoint(self,addr):
		if(isrunning()):
			print("~Halt at chechpoint can't be set.........\\n")
			print("~Target is in running state\\n")
			return False
		if addr == "":
			print '~Give proper input out of one possible 1. All 2. Next 3. Checkpoint Address\\n'
			return False
		obj = CheckpointManager.getInstance()
		if (addr == 'ALL') | (addr == 'all'):
			obj.handleAddChkPt(addr,"")
		elif (addr == 'NEXT') | (addr == 'next'):
			obj.handleAddChkPt(addr,"")
		elif (addr == 'none') | (addr == 'NONE'):
			obj.handleAddChkPt('NONE',addr)
		else:
			try:
				addr=rectifyValue(addr,1)
				addr=addr[2:len(addr)]
				obj.handleAddChkPt('CHK',addr)
			except ValueError:
				print '~Give proper input\\n'
				return False
		print '~Halt at checkpoint : %s successfully set \\n'%addr
		
	"""	This command is used to clear halt at particular checkpoint.
	"""	
	
	def removeHaltCheckpoint(self,addr):
		if(isrunning()):
			print("~Halt at chechpoint can't be set.........\\n")
			print("~Target is in running state\\n")
			return False
		if addr == "":
			print '~Give proper input\\n'
			return False
		obj = CheckpointManager.getInstance()
		status = obj.handleRemChkPt(str(addr))
		if int(status)==0:
			print "~Requested checkpoint is not available in the list\\n"
			return False
		print '~Halt at checkpoint : %s successfully removed \\n'%addr
	
	""" This command is used to read and update the bytes from indexed IO port.
		index : indec port address
		data : data port address
		start : offset
		count : number of bytes to read or update
		newValue : null in case of read ; bytes to update in case of write	
	"""
	def indexedIO(self,index,data,start,count,*newValue):
		if(isrunning()):
			print("~Indexed IO read/write cannot execute..........\\n")
			print("~Target is in running state\\n")
			return False
		index=rectifyValue(index)
		data=rectifyValue(data)
		start=rectifyValue(start)
		count=rectifyValue(count)
		if(count<=0 or count>255):
			print("~Length should be in between 1 and 0xff\n")
			return False
		if(start>256 or start<0):
			print("~offset should be in between 0 to 0xff")
			return False
		if len(newValue) == 0:
			print("~IndexedIO Read...\\n")
			obj=DbgCmdReadIIO(index, data, start, count)
			status=obj.execTarget()
			bytes=[]
			if int(status)==0:
				print("~Indexed IO Read Failure...\\n")
				return False
			bytes = obj.getScriptOutput()
			i=0
			for byte in bytes: 
				i+=1
				print("~"+format(byte,'02x')+" ")
				if i%16==0:
					print("~\\n")
			print("~\\n")
			return byte
		else:
			print("~IndexedIO write...\\n")
			array=self.fullByteArray(1,*newValue)
			if(len(array) < count):
				print("~Please provide valid number of byte to write\\n")
				return False
			for vl in newValue:
				if(vl>255):
					print("~Please provide the values in between 0-ff\\n")
					return False
			for i in range(count):
				obj = DbgCmdWriteIIO(1,data,index,start+i,1,array[i])
				success = obj.execTarget()
				if int(success)==0:
					print("~IndexedIO Command Failed\\n")
					return False
			print '~IndexedIO port updated successfully\\n'
	
	"""	This command is used to list all the handles installed
	"""
	
	def listAllHandles(self):
		if(isrunning()):
			print("~List all handles cannot execute..........\\n")
			print("~Target is in running state\\n")
		obj = DbgCmdGetTargetState()
		success = obj.execTarget()
		if int(success)==0:
			print "~list all handles Command Failed\\n"
			return False
		a = obj.getOutput()
		if a[0] == 0:
			print '~List handles all wont work in PEI Phase Before MemoryInit\\n'		
			return False
		if a[0] == 1:
			print '~List handles all wont work in PEI Phase After MemoryInit\\n'
			return False
		if a[0] == 3:
			obj1 = DbgCmdListHandles()
			success = obj1.execTarget()
			if int(success)==0:
				print "~List all handles wont work in this module\\n"
				return False
			obj1.listAllHandles()
		else:
			print '~List all handles wont work in this module\\n'
			return False
		
	"""	This command is used to list all the protocols with its name and guid installed on
		particular handle
		index : index of the handle
	"""
	def listProtocols(self,index):
		if(isrunning()):
			print("~List protocols command cannot execute..........\\n")
			print("~Target is in running state\\n")
		if index <=0 :
			print '~Index should be greater than 0\\n'
			return
		obj = DbgCmdGetTargetState()
		success = obj.execTarget()
		if int(success)==0:
			print "~list protocols Command Failed\\n"
			return False
		a = obj.getOutput()
		if a[0] == 0:
			print '~List protocols wont work in PEI Phase Before MemoryInit\\n'		
			return False
		if a[0] == 1:
			print '~List protocols wont work in PEI Phase After MemoryInit\\n'
			return False
		if a[0] == 3:
			obj1 = DbgCmdListHandles()
			success = obj1.execTarget()
			if int(success)==0:
				print "~List protocols wont work in this module\\n"
				return False
			count = obj1.getHandleCount()
			if index > count:
				print '~Handle count with given index is not available\\n'
				return False
			obj2 = DbgCmdExpandHandles(index)
			success = obj2.execTarget()
			if int(success)==0:
				print '~List protocols wont work in this module\\n'
				return False
			obj2.listProtocols()
		else:
			print '~List protocols wont work in this module\\n'
			return False
	
	"""	This command is used to list all handles which installed protocols supplied in the arguments	
		guid : guid of particular protocol
	"""
	def listHandles(self,guid):
		if(isrunning()):
			print("~List handles command cannot execute..........\\n")
			print("~Target is in running state\\n")
		obj = DbgCmdGetTargetState()
		success = obj.execTarget()
		if int(success)==0:
			print "~list handles Command Failed"
			return False
		a = obj.getOutput()
		if a[0] == 0:
			print '~List handles wont work in PEI Phase Before MemoryInit\\n'		
			return False
		if a[0] == 1:
			print '~List handles wont work in PEI Phase After MemoryInit\\n'
			return False
		if a[0] == 3:
			obj = MICommandExpandProtocols()
			bytes = obj.getGuidBytes(guid)
			if bytes != None:
				obj1 = DbgCmdExpandProtocols(bytes)
				success = obj1.execTarget()
				if int(success)==0:
					return False
				obj1.listHandles()
		else:
			print '~List handles wont work in this module\\n'
			return False
	
	"""	This command is used to load firmware volume
		arg : ROM or BIN file path
	"""
	def LoadFV(self,arg):
		if(isrunning()):
			print("~Load FV command cannot execute..........\\n")
			print("~Target is in running state\\n")
		try:
			file1 = open(arg,"r")
		except IOError:
			print '~File Does not Exist\\n'
			return
		obj = MICommandLoadFV()
		obj.fullPath = arg
		obj.execute()
		print '~LoadFV command received\\n'
		
	"""	This command is used to enable or disable target traces in DebugMessageLog,txt file
		val : True  -> log the traces
			  False -> dont log the traces
	"""
	def logDebugMsg(self,val):
		if type(val).__name__!='bool':
			print '~Argument must be either True of False\\n'
			return
		if val == True:
			self.commands_logging()
		else:
			self.stopdallog()
			
	"""	This command is used to open and close the console redirection window
		val : True  -> open the window
			  False -> close the window
	"""
	def consoleSupport(self,val):
		if(isrunning()):
			print("~Console Window can't open..........\\n")
			print("~Target is in running state\\n")
		if type(val).__name__!='bool':
			print '~Argument must be either True of False\\n'
			return
		obj = ConsoleRedirector()
		obj.consoleWindow(val)
		
		
	def PrinttraceMessage(self,val):
		if type(val).__name__!='bool':
			print '~Argument must be either True of False\\n'
			return
		if val == True:
			self.commands_logging()
		else:
			self.stopdallog()
			
	def PrintChkPt(self,val):
		ami.port(0x80,val)
		print '~Checkpoint update successfully\\n'
	def baseaccess(self):
		return self	
	def correctType(self,val,formatcode=0):
		if formatcode==0:
			if type(val)==str:
				if val.startswith('0x')==False and val.startswith('0X')==False:
					val='0x'+val
				return long(val,16)
			elif type(val)==int or long:
				return val
		elif formatcode==1:
			if type(val)==str:
				if val.find("0x")==-1:
					val="0x"+val
				return val
			elif type(val)==int or long:
				strval=hex(val)
				if strval.find('L')==-1:
					return strval
				else:
					return strval[0:len(strval)-1]
itp = ami_class()
itpii=ami_class()
ami=ami_class()
pci_config=itp.pci_config
pci_configb=itp.pci_configb
pci_configd=itp.pci_configd
pci_configw=itp.pci_configw
itp.threads[itp.vp].bits=itp.bits
itp.threads[itp.vp].mem=itp.mem
itp.threads[itp.vp].memblock=itp.memblock
itp.threads[itp.vp].dport=itp.dport
itp.threads[itp.vp].port=itp.port
itp.threads[itp.vp].wport=itp.wport
#itp.threads[itp.vp].cv.isrunning=itp.cv.isrunning
itp.threads[itp.vp].msr=itp.msr
itp.threads[itp.vp].halt=itp.halt
itp.threads[itp.vp].cpuid_eax=itp.cpuid_eax
itp.threads[itp.vp].cpuid_ebx=itp.cpuid_ebx
itp.threads[itp.vp].cpuid_ecx=itp.cpuid_ecx
itp.threads[itp.vp].cpuid_edx=itp.cpuid_edx
itp.threads[itp.vp].regs=itp.regs
itp.threads[itp.vp].cv.isrunning=itp.cv.isrunning
# Publish all datatype global definitions to __main__ namespac
for defList in dir():
    if defList != 'defList' and not defList.startswith('_'):
        setattr(__main__, defList, eval(defList))
del defList    
	
