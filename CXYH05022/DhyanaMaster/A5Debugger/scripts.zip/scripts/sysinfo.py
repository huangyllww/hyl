from MasterScript import *
def sysinfo():
	ami.status()
	ami.printf("Current Instruction : %x\n",ami.valueofCurrentInstruction())
	ami.printf("\nList Of Loaded Drivers\n")
	ami.ListDrivers()
	if isrunning() == False:
		ami.cause()
