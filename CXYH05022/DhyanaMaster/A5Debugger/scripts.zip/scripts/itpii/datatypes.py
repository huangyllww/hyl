###
## AMI Copyright
###
"""
AMI defined datatypes for supporting the scripting beyond the built-in types
"""

import __main__
import ctypes as _ctypes
import sys as _sys

_STR_LEN_LIMIT = 256

''' 
Define a generic numeric class which can represent any numeric datatype 
Class provide support for signed/unsigned and fixed/floating point numbers
'''
class _GenericNumberClass(object):
	# Initialization function used to store value and identify the type of value 
	# that needs to be used
	def __init__(self, value, byteCount = 1, isSigned = False, isFloating = False):
		self._isFloating = isFloating
		self._isSigned = isSigned
		self._byteCount = byteCount
		if(type(value)!=list):
			self._mask = ((1 << (byteCount * 8)) - 1) - (1 * isSigned)
		#print "~ _GenericNumberClass init called with mask = 0x%x\\n" %self._mask
		if(isFloating):
			if(byteCount == 4):
				self.value = float(_ctypes.c_float(value))
			elif(byteCount == 8):
				self.value = float(_ctypes.c_double(value))
			else:
				self.value = float(_ctypes.c_double(value)) #c_longdouble not available
		else :
			if(isSigned):
				if(type(value)==list):
					self.value=value
				elif(byteCount == 1):
					self.value = int(_ctypes.c_short(value)) & self._mask
				elif(byteCount == 2):
					self.value = int(_ctypes.c_int16(value)) & self._mask 
				elif(byteCount == 4):
					self.value = int(_ctypes.c_int32(value)) & self._mask
				elif(byteCount == 8):
					self.value = int(_ctypes.c_int64(value)) & self._mask
				else:
					self._mask = 0xffffffffffffffff - 1
					self.value = int(_ctypes.c_int64(value)) & self._mask
			else:
				if(type(value)==list):
					self.value=value
				elif(byteCount == 1):
					self.value = int(_ctypes.c_ushort(value)) & self._mask
				elif(byteCount == 2):
					self.value = int(_ctypes.c_uint16(value)) & self._mask
				elif(byteCount == 4):
					self.value = int(_ctypes.c_uint32(value)) & self._mask
				elif(byteCount == 8): 
					self.value = int(_ctypes.c_uint64(value)) & self._mask
				else:
					self._mask = 0xffffffffffffffff
					self.value = int(_ctypes.c_uint64(value)) & (self._mask)
							
	# Arithmetic operations	
	def __add__(self, other):   
		return self.value + other		
	def __sub__(self, other):			   
		return self.value - other
	def __mul__(self, other):			   
		return self.value * other
	def __div__(self, other):			   
		return self.value / other
	def __mod__(self, other):			   
		return self.value % other
	def __floordiv__(self, other):		  
		return self.value // other
	def __divmod__(self, other):			
		return divmod(self.value, other)
	def __pow__(self, other):  
		return self.value ** other

	# Bitwise operations		
	def __lshift__(self, other):			
		return self.value << other
	def __rshift__(self, other):			
		return self.value >> other
	def __and__(self, other):			   
		return self.value & other
	def __or__(self, other):				
		return self.value | other
	def __xor__(self, other):			   
		return self.value ^ other

	# Reflective arithmetic and logical  operations
	def __radd__(self, other):  
		return other + self.value		
	def __rsub__(self, other):  
		return other - self.value   
	def __rmul__(self, other):			  
		return other * self.value
	def __rdiv__(self, other):			  
		return other / self.value
	def __rmod__(self, other):			  
		return other % self.value
	def __rdivmod__(self, other):		   
		return divmod(other, self.value)
	def __rfloordiv__(self, other):		 
		return other // self.value
	def __rand__(self, other):			  
		return other & self.value
	def __ror__(self, other):			   
		return other | self.value
	def __rxor__(self, other):			  
		return other ^ self.value
	def __rpow__(self, other):			  
		return pow(other, self.value)
	def __rlshift__(self, other):		   
		return other << self.value
	def __rrshift__(self, other):		   
		return other >> self.value

	# Type conversions	 
	def __int__(self):					  
		return int(self.value)
	def __long__(self):					 
		return long(self.value)
	def __float__(self):					
		return float(self.value)
	def __oct__(self):					  
		return oct(self.value)
	def __hex__(self):					  
		return hex(self.value)
	def __str__(self):					  
		return str(self.value)
	def __coerce__(self,other):
		if(self.isFloating):
			return float(self).__coerce__(other)
		else:			
			return long(self).__coerce__(other)
	def __repr__(self):					 
		return repr(self.value)
	def __nonzero__(self):				  
		return bool(self.value)
	def __hash__(self):					 
		return hash(self.value)
	def changeByteOrder(self, item):
		res=[]
		while(len(item)>2):
			temp=item[:2]
			res.insert(0,temp)
			item=item[2:]
		if(len(item)>0):
			res.insert(0,item)
		final= ''.join(res)
		return final
			
	# getBitArray converts data into list array
	def getBitArray(self,data):
		num=0
		result=[]
		if type(data) is list:
			num=(self._byteCount*8)
			for item in reversed(data):
				if(num-32>0):
					num1=num-32
					num=num-32
				else:
					num1=num
				item=hex(item)
				item=item.replace('0x','')
				item=item.replace('L','')
				# change order of the recieved bytes for list
				item=self.changeByteOrder(item)
				item=long(item,16)
				for x in range((num1-1),-1,-1):
					if (item & (1<<x)) >0:
						result.append(1)
					else:
						result.append(0)
		if type(data) is int :
			num=32
		elif type(data) is float:
			num=64
		else:
			num=64;
		if not result:
			for x in range((num-1),-1,-1):
				if (data & (1<<x)) >0:
					result.append(1)
				else:
					result.append(0)
		result.reverse()
		return result
	# getBitDatafromArray returns BitData formed from list of bits
	def getBitDatafromArray(self,arrayList):
		bsize=0
		if len(arrayList)<=8:
			bsize=1
		elif len(arrayList)<=16:
			bsize=2
		elif len(arrayList)<=32:
			bsize=4
		elif len(arrayList)<=64:
			bsize=8
		else:
			bsize=8
		totalSize=8*bsize
		b=BitData(totalSize)
		for x in range(0,(bsize*8)):
			if x<=(len(arrayList)-1):
				if arrayList[x]==1:
					b.value=b.value|(1<<x)
		return b
	# copy returns a BitData
	def copy(self,offset,size):
		a= self.getBitArray(self.value)
		resList=[]
		if offset+size>self._byteCount*8:
			print "~IndexOutOfRangeException: Index was outside the bounds of the array."
			return None
		for x in range(offset,offset+size):
			resList.append(a[x])
		return self.getBitDatafromArray(resList)
	def __getitem__(self,index):
		a=self.getBitArray(self.value)
		return a[index]
	# Logical comparison operators
	def __lt__(self, other):				return self.value < other
	def __le__(self, other):				return self.value <= other
	def __eq__(self, other):				return self.value == other
	def __ne__(self, other):				return self.value != other
	def __gt__(self, other):				return self.value > other
	def __ge__(self, other):				return self.value >= other

	# Augmented assignments
	def __iadd__(self, other):
		self.value += other
		return self
	def __isub__(self, other):
		self.value -= other
		return self
	def __imul__(self, other):
		self.value *= other
		return self
	def __idiv__(self, other):
		self.value /= other
		return self
	def __ifloordiv__(self, other):
		self.value //= other
		return self
	def __imod__(self, other):
		self.value %= other
		return self
	def __ipow__(self, other):
		self.value = other ** self.value
		return self
	def __ilshift__(self, other):
		self.value <<= other
		return self
	def __irshift__(self, other):
		self.value >>= other
		return self
	def __iand__(self, other):
		self.value &= other;
		return self
	def __ixor__(self, other):
		self.value ^= other
		return self
	def __ior__(self, other):
		self.value |= other
		return self
	def __neg__(self):
		return -self.value
	def __pos__(self):
		return +self.value
	def __abs__(self):
		return abs(self.value)
	def __invert__(self):
		return ~self.value

#		
# Public classes
#
''' Class definition for a C uint8 equivalent one byte unsigned value '''
class Ord1(_GenericNumberClass):
	def __init__(self, value=0):
		_GenericNumberClass.__init__(self, int(value), 1, False)
	def __setattr__(self, name, value):
		if(name == "value"):
			value = value & self._mask
		self.__dict__[name] = value


''' Class definition for a C uint16 equivalent two byte unsigned value '''
class Ord2(_GenericNumberClass):
	def __init__(self, value=0):
		#print "~ Ord2 init called with value = 0x%x\\n" %value
		_GenericNumberClass.__init__(self, int(value), 2, False)
	def __setattr__(self, name, value):
		if(name == "value"):
			value = value & self._mask
		self.__dict__[name] = value

''' Class definition for a C uint32 equivalent 4 byte unsigned value '''
class Ord4(_GenericNumberClass):
	def __init__(self, value=0):
		_GenericNumberClass.__init__(self, int(value), 4, False)
	def __setattr__(self, name, value):
		if(name == "value"):
			value = value & self._mask
		self.__dict__[name] = value

''' Class definition for a C uint64 equivalent 8 byte unsigned value '''
class Ord8(_GenericNumberClass):
	def __init__(self, value=0):
		_GenericNumberClass.__init__(self, int(value), 8, False)
	def __setattr__(self, name, value):
		if(name == "value"):
			value = value & self._mask
		self.__dict__[name] = value
		

''' Class definition for a C int8 equivalent 1 byte signed value '''
class Int1(_GenericNumberClass):
	def __init__(self, value=0):
		_GenericNumberClass.__init__(self, int(value), 1, True)
	def __setattr__(self, name, value):
		if(name == "value"):
			value = value & self._mask
		self.__dict__[name] = value

''' Class definition for a C int16 equivalent 2 byte signed value '''
class Int2(_GenericNumberClass):
	def __init__(self, value=0):
		_GenericNumberClass.__init__(self, int(value), 2, True)
	def __setattr__(self, name, value):
		if(name == "value"):
			value = value & self._mask
		self.__dict__[name] = value

''' Class definition for a C int32 equivalent 4 byte signed value '''
class Int4(_GenericNumberClass):
	def __init__(self, value=0):
		_GenericNumberClass.__init__(self, int(value), 4, True)
	def __setattr__(self, name, value):
		if(name == "value"):
			value = value & self._mask
		self.__dict__[name] = value

''' Class definition for a C int64 equivalent 8 byte signed value '''
class Int8(_GenericNumberClass):
	def __init__(self, value=0):
		_GenericNumberClass.__init__(self, int(value), 8, True)
	def __setattr__(self, name, value):
		if(name == "value"):
			value = value & self._mask
		self.__dict__[name] = value

''' Class definition for a C float equivalent 4 byte floating point value '''
class Real4(_GenericNumberClass):
	def __init__(self, value=0.0):
		_GenericNumberClass.__init__(self, value, 4, True, True)
	def __setattr__(self, name, value):
		self.__dict__[name] = value		

''' Class definition for a C float equivalent 4 byte floating point value '''
class Real8(_ctypes.c_float, _GenericNumberClass):
	def __init__(self, value=0.0):
		_GenericNumberClass.__init__(self, value, 8, True, True)
	def __setattr__(self, name, value):
		self.__dict__[name] = value		


''' Class definition for a C float equivalent 4 byte floating point value '''
class Real10(_GenericNumberClass):
	def __init__(self, value=0.0):
		_GenericNumberClass.__init__(self, value, 10, True, True)
	def __setattr__(self, name, value):
		self.__dict__[name] = value	
		  
	  
''' Datatype equivalent to C char to hold a single character value '''
class Char(object): 
	def __init__(self, value=''):
		self.value = (str(value)[:1])		
	def __setattr__(self, name, value):
		self.__dict__[name] = value
	def __str__(self):
		return str(self.value)
	
''' Datatype equivalent to C boolean to hold a single True/False value '''
class Bool1(object):
	def __init__(self, value=False):
		self.value = bool(value)
	def __setattr__(self, name, value):
		self.__dict__[name] = value
	def __int__(self):
		return int(self.value)
	def __hex__(self):
		return hex(self.value)
	def __str__(self):
		return str(self.value)
	def __nonzero__(self):				  
		return bool(self.value)


''' Class to hold string similar to C type character array '''	 
class String(object):
	def __init__(self, value=""):
		self.value = (str(value)[0:_STR_LEN_LIMIT])
	
	# Conversion operations	
	def __repr__(self):					 
		return repr(self.value)
	def __str__(self):					  
		return str(self.value)
	def __unicode__(self):				  
		return unicode(self.value)
		
	# Comparison operator	
	def __lt__(self, other):				return self.value < other
	def __le__(self, other):				return self.value <= other
	def __eq__(self, other):				return self.value == other
	def __ne__(self, other):				return self.value != other
	def __gt__(self, other):				return self.value > other
	def __ge__(self, other):				return self.value >= other

	# Concatination operations
	def __add__(self, other):			   
		return self.value + str(other)
	def __radd__(self, other):			  
		return str(other) + self.value
	def __iadd__(self, other):			  
		self.value = self.value + str(other) 
		return self
	def __sub__(self, other):			   
		return self.value - str(other)
	def __rsub__(self, other):			  
		return str(other) - self.value
	def __isub__(self, other):			  
		self.value = self.value - str(other) 
		return self

	# String Operations	
	def __len__(self):					  
		return len(self.value)
	def __getitem__(self, key):			 
		return self.value[key]
	def __setitem__(self, key, value):	  
		self.value[key] = value
	def __delitem__(self, key):			 
		del self.value[key]
	def __iter__(self):					 
		return iter(self.value)
	def __reversed__(self):				 
		return reversed(self.value)
	def __contains__(self, item):		   
		return item in self.value

''' Pointer datatype to hold an address value
 Defined as Ord8 to hold maximum of 64 bit address values '''
class Pointer(Ord8):
	pass

class BitData(_GenericNumberClass):
	try:
		def __init__(self,val1,val2=0):
			if(type(val2)==list):
				if(val1%8!=0):
					print '~ValueError: Val1 is not valid\\n'
				res=[]
				size=0
				rec=val1
				#size of each element should be 32 bits
				for item in val2:
					if item>0xffffffff:
						print '~Exception: The array type used to initialize BitData is not supported.'
						return
					item=item&0xffffffff
					rec1=rec
					rec=rec-32
					if(rec<=0):
						if rec1==8:
							item=item&0xff
							size=size+8
						if rec1==16:
							item=item&0xffff
							size=size+16
						if rec1==24:
							item=item&0xffffff
							size=size+24
						if rec1==32:
							item=item&0xffffffff
							size=size+32
						res.append(item)
						break
					else:
						item=item&0xffffffff
						size=size+32
						res.append(item)
				self.len=size/4
				_GenericNumberClass.__init__(self, res,size/8, False)
				return
			if (type(val1)==str) | (type(val2)==str):
				print '~ValueError: Give Integer Value\\n'
				return
			if val1 == 8:
				self.len = 2
				_GenericNumberClass.__init__(self, int(val2), 1, False)
			elif val1 == 16:
				self.len = 4
				_GenericNumberClass.__init__(self, int(val2), 2, False)
			elif val1 == 32:
				self.len = 8
				_GenericNumberClass.__init__(self, int(val2), 4, False)
			elif val1 == 64:
				self.len = 16
				_GenericNumberClass.__init__(self, int(val2), 8, False)
			else:
				print '~Give first argument as 8,16,32,64 only\\n'
		def __setattr__(self, name, val2):
			if(name == "val2"):
				val2 = val2 & self._mask
			self.__dict__[name] = val2
		def __len__(self):
			return self.length()
		def __getslice__(self, i, j):
			if j == _sys.maxsize:
				j = self.BitSize - 1
				try:
					i = long(i)
				except:
					raise TypeError("argument parameter should be integers, not %s" % type(i))
				try:
					j = long(j)
				except:
					raise TypeError("argument parameter should be integers, not %s" % type(j))
			if i == j:
				return self.__getitem__(i)
			if i > j:
				startBit = j
				bitSize = i - j
			else:
				startBit = i
				bitSize = j - i
			return self.Copy(startBit, bitSize) # return BitData
		def length(self):
			return self.len
		def ShiftLeft(self,offset,size,count):
				return self.__lshift__(count)
		def Copy(self, *args):
			return super(BitData, self).copy(*args)
		def getValue(self):
			return self.value
		def set_BitSize(self,size):
			byteCount=size/8
			value=self.value
			isFloating=self._isFloating
			isSigned=self._isSigned
			self._mask = ((1 << (byteCount * 8)) - 1) - (1 * isSigned)
			if(isFloating):
				if(byteCount == 4):
					self.value = float(_ctypes.c_float(value))
					self.len=8
				elif(byteCount == 8):
					self.value = float(_ctypes.c_double(value))
					self.len=16
				else:
					self.value = float(_ctypes.c_double(value)) #c_longdouble not available
					self.len=16
			else :
				if(isSigned):
					if(byteCount == 1):
						self.value = int(_ctypes.c_short(value)) & self._mask
						self.len=2
					elif(byteCount == 2):
						self.value = int(_ctypes.c_int16(value)) & self._mask
						self.len=4
					elif(byteCount == 4):
						self.value = int(_ctypes.c_int32(value)) & self._mask
						self.len=8
					elif(byteCount == 8):
						self.value = int(_ctypes.c_int64(value)) & self._mask
						self.len=16
					else:
						self._mask = 0xffffffffffffffff - 1
						self.value = int(_ctypes.c_int64(value)) & self._mask
						self.len=16
				else:
					if(byteCount == 1):
						self.value = int(_ctypes.c_ushort(value)) & self._mask
						self.len=2
					elif(byteCount == 2):
						self.value = int(_ctypes.c_uint16(value)) & self._mask
						self.len=4
					elif(byteCount == 4):
						self.value = int(_ctypes.c_uint32(value)) & self._mask
						self.len=8
					elif(byteCount == 8):
						self.value = int(_ctypes.c_uint64(value)) & self._mask
						self.len=16
					else:
						self._mask = 0xffffffffffffffff
						self.value = int(_ctypes.c_uint64(value)) & (self._mask)
						self.len=16
			self.length()


	except TypeError:
		print '~no constructor matches given arguments\\n'
		
''' Publish all datatype global definitions to __main__ namespace '''
for defList in dir():
	if defList != 'defList' and not defList.startswith('_'):
		setattr(__main__, defList, eval(defList))
del defList

