from MasterScript import itp
def enable():
	return True
