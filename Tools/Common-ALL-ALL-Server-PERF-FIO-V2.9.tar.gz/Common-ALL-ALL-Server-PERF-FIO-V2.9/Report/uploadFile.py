# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import sys
import os
import logging
import json
import argparse
import commands
import re
from collections import Iterable

import requests

logPath = __file__
logPath = '{}_execDetail.log'.format(logPath.split('.')[0])

class Logger(object):

    relations = {
        'debug': logging.DEBUG,
        'info': logging.INFO,
        'warning': logging.WARNING,
        'error': logging.ERROR,
        'crit': logging.CRITICAL
    }

    def __init__(self, filename, level=relations['info'],fmt="%(asctime)s %(message)s", datefmt="%Y-%m-%d %H:%M:%S"):
        self.logger = logging.getLogger(filename)
        self.logger.setLevel(level=level)

        formatter = logging.Formatter(fmt=fmt, datefmt=datefmt)

        file_handler = logging.FileHandler(filename)
        file_handler.setLevel(level=level)
        file_handler.setFormatter(formatter)

        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(level)
        stream_handler.setFormatter(formatter)

        self.logger.addHandler(file_handler)
        self.logger.addHandler(stream_handler)

myLogging = Logger(logPath).logger

class Utils(object):

    @staticmethod
    def scanRemoteMachine(url, port=80):
        return_status = True
        cmd = r'nmap {} -p {}'.format(url, port)
        status, result = Utils.executeCMD(cmd)
        if status != 0:
            myLogging.error("CMD %s running occur error,detail msg is %s please check" % (cmd, result))
            return_status = False
        else:
            if not re.search('tcp open', result, re.I | re.M):
                myLogging.error("平台性能展示服务端口未开放请联系管理员")
                return_status = False
        return return_status

    @staticmethod
    def executeCMD(cmd):
        status, out = commands.getstatusoutput(cmd)
        return status, out

    @staticmethod
    def getIPPort(url):
        urlList = re.split('/+', url)
        ip_port = urlList[1]
        ip_port_list = ip_port.split(':')
        if len(ip_port_list) == 1:
            return urlList[1], 80
        else:
            return ip_port_list[0:2]


class UploadFiles(object):

    def __init__(self, username, password, confName, testItem, url, timeout=30):
        self.username = username
        self.password = password
        self.confName = confName
        self.testItem = testItem
        self.url = url
        self.timeout = timeout
        self.fileList = []

    def addFile(self, fileName, filePath):
        if not os.path.exists(filePath):
            myLogging.error('fileName {} filePath {} not exist'.format(fileName, filePath))
            sys.exit(1)
        fileItem = ("uploadfile[]", (fileName, open(filePath, "rb")))
        self.fileList.append(fileItem)

    def addFiles(self, fileList):
        fileListItem = fileList[0]
        if isinstance(fileListItem, str):
            length = len(fileList)
            for index in range(0, length, 2):
                self.addFile(fileList[index], fileList[index + 1])
        elif isinstance(fileListItem, tuple):
            for fileItem in fileList:
                self.addFile(fileItem[0], fileItem[1])
        elif isinstance(fileItem, dict):
            for fileItem in fileList:
                fileName = fileItem.get('fileName')
                filePath = fileItem.get('filePath')
                self.addFile(fileName, filePath)
        else:
            myLogging.error("您出入的文件列表不符合处理规则,请出入['fileName','filePath']"
                          "或者传入[('fileName','filePath')]或者传入"
                          "[{'fileName':fileName,'filePath':'filePath'}]")
            sys.exit(1)

    def uploadFiles(self):
        userMsg = {
            "username": self.username,
            "password": self.password,
            "confName": self.confName,
            "testItem": self.testItem,
        }
        try:
            return_msg = requests.post(self.url, data=userMsg, files=self.fileList,
                                       timeout=self.timeout)
            return return_msg
        except Exception as e:
            logging.warning('未能正常上传文件，原因为：{}'.format(e.message))
            # raise e

    def filesExist(self, fileList):
        exist = True
        length = len(fileList)
        for index in range(1, length, 2):
            filePath = fileList[index]
            fileName = fileList[index - 1]
            if not os.path.exists(filePath):
                myLogging.error('fileName {} filePath {} not exist'.format(fileName, filePath))
                exist = False
        return exist


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--username", type=str, required=True, help="平台用户名")
    parser.add_argument("--password", type=str, required=True, help="平台用户名密码")
    parser.add_argument("--confName", type=str, required=True, help="项目配置名称")
    parser.add_argument("--testItem", type=str, required=True,
                        choices=['speccpu', 'linpack', 'stream', 'mlc', 'autoraid', 'fio_single',
                                 'fio_whole', 'netperf', 'lmbench', 'specpower'],
                        help="测试工具名称")
    parser.add_argument("--url", type=str, default=r"http://validation.sugon.com/PerformanceShow/uploadFiles/",
                        help="上传文件地址,默认为：http://validation.sugon.com/PerformanceShow/uploadFiles/")
    parser.add_argument("--targetFileMsg", nargs='+', help="上传文件的文件名以及文件路径;'test1' './test01'")
    args = parser.parse_args()
    username = args.username
    password = args.password
    confName = args.confName
    testItem = args.testItem
    url = args.url
    targetFileMsg = args.targetFileMsg

    ip, port = Utils.getIPPort(url)
    status = Utils.scanRemoteMachine(ip, port)
    if status:
        uploadObj = UploadFiles(username, password, confName, testItem, url)
        if targetFileMsg:
            try:
                if isinstance(targetFileMsg, Iterable):
                    if targetFileMsg:
                        if uploadObj.filesExist(targetFileMsg):
                            uploadObj.addFiles(targetFileMsg)
                            return_msg = uploadObj.uploadFiles()
                            return_json = return_msg.json()
                            if return_json.has_key('fail'):
                                myLogging.error(return_json['fail'])
                            elif return_json.has_key('pass'):
                                myLogging.info(return_json['pass'])
                        else:
                            sys.exit(1)
                    else:
                        myLogging.error('您必须指定上传文件的文件名以及路径')
                        sys.exit(1)
                else:
                    myLogging.error('您必须以列表的形式指定上传文件的文件名以及路径')
                    sys.exit(1)
            except Exception as e:
                myLogging.error(e)
                sys.exit(1)
    else:
        sys.exit(1)
