#!/bin/ env python
import argparse;
import numpy as np;
import matplotlib as mpl;
mpl.use('agg')
import matplotlib.pyplot as plt;
from numpy import arange;
import os;
import sys;
from matplotlib.lines import lineStyles;
from matplotlib.ticker import  MultipleLocator;
from matplotlib.ticker import  FormatStrFormatter;
import collections;
from matplotlib import ticker;
import random;
from matplotlib.pyplot import  xticks;

def convert(x):
    length = len(x)
    if x[length-1].lower() == 'k':
        x = long(x[0:length-1]) * 1024
    elif x[length-1].lower() == 'm':
        x = long(x[0:length-1]) * 1024 * 1024
    elif x[length-2:length].lower() == 'mb':
        x = float(x[0:length-2]) * 1024 * 1024
    else:
        print "input parameter wrong"
        return 1
    return x

def my_cmp(x, y):
    if convert(x) < convert(y):
        return -1
    if convert(x) > convert(y):
        return 1
    return 0
def draw_lines(dictas,title='lines',xlabel='x',ylabel='y',storePath='.',marker='o',linestyle='-'):
    if isinstance(dictas, dict): 
        if len(dictas) == 0:
            print "Please specify the value of x y as a dictionary"
            return 1
        plt.switch_backend('agg')
        plt.figure(figsize=(20, 15))  
        colors = ['aqua','black','blue','red','green','brown','coral','gold','fuchsia','grey']
        newdict = collections.OrderedDict()
        minylist = []
        ax = plt.gca()
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        for vl in dictas.values():
            minylist.append(min(vl.values()))
        min_y = min(minylist)
        if min_y > 0:
            min_y = 0
        else:
            min_y = min_y + min_y
        for kl,vl in dictas.items():
            seq_keys = sorted(vl.keys(), my_cmp)
            for temp_i in seq_keys:
                newdict[temp_i] = vl[temp_i]
            length = len(colors)
            color_index = random.randint(0,length-1)
            color = colors[color_index]
            colors.remove(color)
            label = 'QD' + repr(kl)
            num_x = [convert(x) for x in seq_keys]
            xticks(np.arange(len(num_x)),seq_keys)
            plt.plot(newdict.values(),marker=marker,linestyle=linestyle,color=color,label=label)
            plt.legend(loc=8,frameon=False,borderaxespad=-7,ncol=len(minylist)/2)
        savePath = os.path.join(storePath,title+'.png')
        plt.savefig(savePath)

def draw_point(dicta,title='point',xlabel='x',ylabel='y',storePath='.',color='red',marker='+',linestyle='',xinterval=5000,yinterval=5000):
	plt.switch_backend('agg')
	#ax = plt.subplot()
	ind = len(dicta)
	if isinstance(dicta, dict): 
		if ind == 0:
			print "Please specify the value of x y as a dictionary"
			return 1
		max_x = max(dicta.keys()) + xinterval
		min_x = min(dicta.keys())
		xmajorLocator = MultipleLocator(min_x)
		if min_x > 0:
			min_x = 0
		else:
			min_x = min_x - xinterval
		max_y = max(dicta.values()) + yinterval
		min_y = min(dicta.values())
		print min_y
		ymajorLocator = MultipleLocator(min_y)
		if min_y > 0:
			min_y = 0
		else:
			min_y = min_y - yinterval
		plt.plot(dicta.keys(), dicta.values(),color=color,marker=marker,linestyle=linestyle)
		plt.xlabel(xlabel)
		plt.ylabel(ylabel)
		plt.title(title)
     
		savePath = os.path.join(storePath,title+'.png')
		plt.savefig(savePath)

def analyis_file(file):
	if not os.path.exists(file):
		print 'wrong'
		return 1
	dicta = {}
	file_ex = open(file,'r')
	lines = file_ex.readlines()
	for line in lines:
		valuable = line.split(',')[0:2]
		dicta[long(valuable[0])] = long(valuable[1])
	return dicta

def preparedata(logfile,xlabel='',ylabel='',storePath='.'):
    if not os.path.exists(logfile):
        print 'logfile is not exist'
        return 1
    tempfile = open(logfile,'r')
    bws = dict()
    iodepth = set()
    testmode = set()
    bwstrcut = dict()
    tempfilelines = tempfile.readlines()[1:]
    for line in tempfilelines:
        linelist = line.split(',')
        iodepth.add(linelist[1])
        testmode.add(linelist[0])
    for tempmode in testmode:
        for tempqd in iodepth:
            for line in tempfilelines:
                linelist = line.split(',')
                if linelist[0].lower() == tempmode and linelist[1].lower() == tempqd:
                    bws[linelist[2]] = float(linelist[8][0:-2])
            bwstrcut[long(tempqd)] = bws
            bws = dict()
        draw_lines(bwstrcut, tempmode+'-100%', xlabel, ylabel, storePath, 'o', '-')
    tempfile.close()

def main():
	parser = argparse.ArgumentParser()
	parser.add_argument("--testmode", required=True,help="Specify the test mode,eg: consistent,stable")
	parser.add_argument("--file", required=True,help="The file record the test message must be required")
	parser.add_argument("--title", required=True,help="The picture title")
	parser.add_argument("--xlabel",required=True,help="x axis name must be required")
	parser.add_argument("--ylabel",required=True,help="y axis name must be required")
	parser.add_argument("--storePath",default='./',help="The picture store path")
	args = parser.parse_args()
	if args.testmode.lower() == 'consistent':
		dicta = analyis_file(args.file)
		title = args.title
		draw_point(dicta,title=args.title,xlabel=args.xlabel,ylabel=args.ylabel,storePath=args.storePath)
	elif args.testmode.lower() == 'stable':
		preparedata(args.file,xlabel=args.xlabel,ylabel=args.ylabel,storePath=args.storePath)
	else:
		print "error hdd type please check"
		sys.exit(1)
if __name__ == "__main__":
	main()
