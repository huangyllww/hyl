#!/bin/sh
cd HPL
sh run_hpl_node.sh
echo Done
echo you should achieve above 900 GF/s on dual socket Naples platform
