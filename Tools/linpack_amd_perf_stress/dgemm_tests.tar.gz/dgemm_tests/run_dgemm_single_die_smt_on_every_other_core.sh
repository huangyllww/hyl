#!/bin/sh
if [ "$#" -ne 1 ]
then
die=0
export GOMP_CPU_AFFINITY="0 2 4 6 8 10 12 14"
else
die=$1
case $die in
        0) export GOMP_CPU_AFFINITY="0 2 4 6 8 10 12 14"; ;;
        1) export GOMP_CPU_AFFINITY="16 18 20 22 24 26 28 30"; ;;
        2) export GOMP_CPU_AFFINITY="32 34 36 38 40 42 44 46"; ;;
        3) export GOMP_CPU_AFFINITY="48 50 52 54 56 58 60 62"; ;;
        4) export GOMP_CPU_AFFINITY="64 66 68 70 72 74 76 78"; ;;
        5) export GOMP_CPU_AFFINITY="80 82 84 86 88 90 92 94"; ;;
        6) export GOMP_CPU_AFFINITY="96 98 100 102 104 106 108 110"; ;;
        7) export GOMP_CPU_AFFINITY="112 114 116 118 120 122 124 126"; ;;
        
   esac;
fi

export OMP_NUM_THREADS=8
export OMP_PROC_BIND=true
export BLIS_IR_NT=1
export BLIS_JR_NT=1
export BLIS_IC_NT=2
export BLIS_JC_NT=4
numactl --cpubind=$die ./test_dgemm.exe > dgemm_die_$die.log

