#!/bin/bash

if [ "$#" -ne 1 ]
then 
core=2 
else
core=$1
fi

export OMP_NUM_THREADS=1
numactl --physcpubind=$core ./test_dgemm.exe > dgemm_single_core_id_$core.log
echo Done single core DGEMM run on core id $core
