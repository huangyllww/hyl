#!/bin/bash

rm -rf dgemm_single_core_id*.log

for core in `seq 0 1 127`;do

./run_dgemm_single_core.sh $core &

done

echo "Wating ~12 minutes to finish..."
sleep 12m
 
cat dgemm_single_core_id_*.log | grep FLOPS | awk '{print $13}' | awk '{s+=$1} END {printf "\n Total GFLOPS= %.0f\n", s}'

