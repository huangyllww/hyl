#!/bin/bash
export OMP_PROC_BIND=true

export GOMP_CPU_AFFINITY="16"
export OMP_NUM_THREADS=2
export BLIS_IR_NT=1
export BLIS_JR_NT=1
export BLIS_IC_NT=1
export BLIS_JC_NT=1
echo 1 core
numactl --cpubind=1 ./test_dgemm.exe > dgemm_die_speedup_1c.log

export GOMP_CPU_AFFINITY="16 24"

export OMP_NUM_THREADS=2
export BLIS_IR_NT=1
export BLIS_JR_NT=1
export BLIS_IC_NT=1
export BLIS_JC_NT=2
echo 2 cores
numactl --cpubind=1 ./test_dgemm.exe > dgemm_die_speedup_2c.log

export GOMP_CPU_AFFINITY="16 18 24 26"
export OMP_NUM_THREADS=4
export BLIS_IR_NT=1
export BLIS_JR_NT=1
export BLIS_IC_NT=1
export BLIS_JC_NT=4
echo 4 cores
numactl --cpubind=1 ./test_dgemm.exe > dgemm_die_speedup_4c.log

export GOMP_CPU_AFFINITY="16 18 20 22 24 26 28 30"
export OMP_NUM_THREADS=8
export BLIS_IR_NT=1
export BLIS_JR_NT=1
export BLIS_IC_NT=2
export BLIS_JC_NT=4
echo 8 cores
numactl --cpubind=1 ./test_dgemm.exe > dgemm_die_speedup_8c.log

export GOMP_CPU_AFFINITY="16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31"
export OMP_NUM_THREADS=16
export BLIS_IR_NT=1
export BLIS_JR_NT=1
export BLIS_IC_NT=2
export BLIS_JC_NT=8
echo 16 cores
numactl --cpubind=1 ./test_dgemm.exe > dgemm_die_speedup_16c.log


