Just run any of the following tests
It assumes system with 256GB total memory (16x16GB dimms) and SMT enabled.

./run_dgemm_multi_die_smt_on_every_other_core.sh  it takes only 90 seconds to run
./run_dgemm_smt_on_every_other_core.sh            it takes only 5 minutes to run
./run_dgemm_smt_on_every_core.sh                  it takes only 12 minutes to run
./run_dgemm_speedup.sh                            it takes only 10 minutes to run

expected performance:
./run_dgemm_multi_die_smt_on_every_other_core.sh  > 1000 DP GF/s
./run_dgemm_smt_on_every_other_core.sh            > 1000 DP GF/s
./run_dgemm_smt_on_every_core.sh                  > 950 DP GF/s
./run_dgemm_speedup.sh                            > 125 DP GF/s for 8 thread run / 20 DP GF/s 1 thread run , speedup=125/20=6.25 out of 8
