#!/bin/bash

rm -rf dgemm_die_*.log

./run_dgemm_single_die_smt_on_every_other_core.sh 0 &
./run_dgemm_single_die_smt_on_every_other_core.sh 1 &
./run_dgemm_single_die_smt_on_every_other_core.sh 2 &
./run_dgemm_single_die_smt_on_every_other_core.sh 3 &
./run_dgemm_single_die_smt_on_every_other_core.sh 4 &
./run_dgemm_single_die_smt_on_every_other_core.sh 5 &
./run_dgemm_single_die_smt_on_every_other_core.sh 6 &
./run_dgemm_single_die_smt_on_every_other_core.sh 7 &

echo "Waiting ~90s to finish..."
sleep 90s
cat dgemm_die_*.log | grep FLOPS | awk '{print $13}' | awk '{s+=$1} END {printf "\n Total GFLOPS= %.0f\n", s}'
