#!/bin/bash
./hgt xgmigenapcbfile -c
if [ -d "apcb_hgt_data" ];then
   rm -rf apcb_hgt_data 
fi
mkdir apcb_hgt_data
mv xgmi_apcb_settings_8.h apcb_hgt_data
mv xgmi_apcb_settings_9.h apcb_hgt_data
mv xgmi_apcb_settings_10.h apcb_hgt_data
