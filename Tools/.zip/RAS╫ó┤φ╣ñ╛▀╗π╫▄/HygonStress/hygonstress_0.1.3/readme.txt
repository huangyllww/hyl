hytonstress is for core and memory stressing.

Usage: ./hygonstress [-c core-num] [-l loops] [-s test_size(KB)

[2018-04-23] version 0.1.3: Fix minus score.