./lUtility /mem rf l16MB.bin 0xff000000 0x1000000
