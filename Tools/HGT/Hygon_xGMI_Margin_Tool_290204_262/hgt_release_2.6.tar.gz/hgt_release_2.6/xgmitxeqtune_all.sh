#!/bin/bash

DieNum=$(lspci -n -d :1450|wc -l)

for((data_rate = 10; data_rate > 7; data_rate--))
do
	for((die = 0; die < $DieNum; die++))
	do
		./hgt xgmitxeqtune -d $die -m 0xffff -r $data_rate 
	done
done

./hgt xgmigenapcbfile

