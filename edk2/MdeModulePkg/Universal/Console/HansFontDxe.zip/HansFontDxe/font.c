/*
 * =====================================================================================
 *
 *       Filename:  font.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  02/20/2013 08:41:46 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  DAI ZHENGHUA (), djx.zhenghua@gmail.com
 *        Company:  
 *
 * =====================================================================================
 */
#include <Protocol/HiiFont.h>
#include "example.data"
