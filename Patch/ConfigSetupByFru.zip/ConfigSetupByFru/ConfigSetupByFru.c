//**This File is adapt CMCC different Fru for different Setup setting-Yanshp-20220613**//
#include <Efi.h>
#include <token.h>
#include <AmiLib.h>
#include <AmiDxeLib.h>
#include <Dxe.h>
#include <library/PcdLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Setup.h>
#include <Library/AmdCbsVariable.h>
#include <Guid/AmdCbsConfig.h>
#include "TseSetupTransfer.h"

VOID
ConfigSetupByFruNotify(
  IN EFI_EVENT Event, 
  IN VOID *Context
  )
{
  EFI_STATUS           Status;
  EFI_GUID             gEfiSetupVariableGuid = SETUP_GUID;
  SETUP_DATA           SetupData;
  UINTN                VariableSize;
  CBS_CONFIG           CbsSetupData;
  UINT32               Attributes;
  CHAR16 *             BoardExtra = L"NULL";
  CHAR16               PreBoardExtra[128];
  UINT8                ResetFlag = 0;
  
  VariableSize = sizeof(PreBoardExtra);
  StrCpy(PreBoardExtra,L"Not Found");

  Status = pRS->GetVariable(
                       L"PreBoardExtra1", 
                       &gEfiRedirFruProtocolGuid,
                       &Attributes,
                       &VariableSize,
                       &PreBoardExtra);
  DEBUG((EFI_D_INFO,"PreBoardExtra = %S, get status is %r\n",PreBoardExtra,Status));

  BoardExtra = (CHAR16 *) PcdGetPtr (PcdBaseBoardExtra1);
  DEBUG ((EFI_D_INFO, "Board Extra 1 = %s\n", BoardExtra));

  if (StrCmp(BoardExtra,PreBoardExtra) != 0 ) {//First reboot after flash BIOS or after flash Fru
    VariableSize = (StrLen(BoardExtra) + 1) * 2;
    Attributes = EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS | EFI_VARIABLE_RUNTIME_ACCESS;
    Status = pRS->SetVariable (L"PreBoardExtra1", &gEfiRedirFruProtocolGuid, Attributes, VariableSize, BoardExtra);
    DEBUG((EFI_D_INFO,"SetVariable PreBoardExtra1 status is %r\n",Status));
    if(EFI_ERROR(Status)){
      return;
    } 

    DEBUG((EFI_D_INFO, "\nConfigSetupByFru Start! \n"));  
    // Get Setup Variable
    VariableSize = sizeof (SetupData);
    Status = gRT->GetVariable ( 
               L"Setup", 
               &gEfiSetupVariableGuid, 
               &Attributes, 
               &VariableSize, 
               &SetupData);
    if(EFI_ERROR(Status)){
      return;
    } 

    VariableSize = sizeof(CBS_CONFIG);
    Status = gRT->GetVariable(
               L"AmdSetup", 
               &gCbsSystemConfigurationGuid,
               &Attributes,
               &VariableSize,
               &CbsSetupData
               );
    if(EFI_ERROR(Status)){
      return;
    } 

    if (StrCmp(BoardExtra,L"CMCC-PC-Setup:01") == 0 ){ //Virtualization
      CbsSetupData.CbsCmnSVMCtrl = 0x01;
      SetupData.SriovSupport = 0x01;
      CbsSetupData.CbsCmnGnbNbIOMMU = 0x01;
      ResetFlag = 1;
    } else if (StrCmp(BoardExtra,L"CMCC-PC-Setup:02") == 0 ){ //Not Virtualization
      CbsSetupData.CbsCmnSVMCtrl = 0x00;
      SetupData.SriovSupport = 0x00;
      CbsSetupData.CbsCmnGnbNbIOMMU = 0x00;
      ResetFlag = 1;
    } 
    
    Status = gRT->SetVariable(
               L"Setup",
               &gEfiSetupVariableGuid,
               Attributes,
               sizeof(SETUP_DATA),
               &SetupData);
    if(EFI_ERROR(Status)){
      return;
    } 

    Status = gRT->SetVariable(
               L"AmdSetup",
               &gCbsSystemConfigurationGuid,
               Attributes,
               sizeof(CBS_CONFIG),
               &CbsSetupData);
    if(EFI_ERROR(Status)){
      return;
    } 

    DEBUG((EFI_D_INFO, "\nConfigSetupByFru End! ResetFlag = %x\n",ResetFlag));  
    if (ResetFlag) {
      gRT->ResetSystem (EfiResetCold, EFI_SUCCESS, 0, NULL);
    }
  } else return;
}

VOID SetupLoadDefaults(    
  IN EFI_EVENT Event, 
  IN VOID *Context
  )
{
  EFI_STATUS                  Status;
  SETUP_DATA                  *SetupData;
  UINTN                       SetupDataSize = sizeof(SETUP_DATA);
  EFI_GUID                    gEfiSetupGuid = SETUP_GUID;
  CBS_CONFIG                  *CbsSetupData;
  UINTN                       CbsSetupDataSize = sizeof(CBS_CONFIG);
  EFI_GUID                    gCbsSystemConfigurationGuid = CBS_SYSTEM_CONFIGURATION_GUID;
  Tse_Setup_transfer          *gTseSetuptransferInterface = NULL;
  EFI_GUID                    gTseTransferGuid = TSE_TRANSFER_GUID;
  EFI_GUID                    gEfiSetupVariableGuid = SETUP_GUID;
  CHAR16 *                    BoardExtra = L"NULL";

  DEBUG((EFI_D_INFO,"LoadDefaults_CMCC Start\n"));
    
  if(gTseSetuptransferInterface == NULL){
    Status = pBS->LocateProtocol(&gTseTransferGuid, NULL, &gTseSetuptransferInterface);
    if(EFI_ERROR(Status)) return;
  }
  BoardExtra = (CHAR16 *) PcdGetPtr (PcdBaseBoardExtra1);

  Status = gTseSetuptransferInterface->VarGetBuffer( L"Setup",gEfiSetupVariableGuid,(UINT8**)&SetupData,&SetupDataSize);
  DEBUG((EFI_D_INFO,"VarGetBuffer gEfiSetupVariableGuid status is %r\n",Status));

  Status = gTseSetuptransferInterface->VarGetBuffer( L"AmdSetup",gCbsSystemConfigurationGuid,(UINT8**)&CbsSetupData,&CbsSetupDataSize);
  DEBUG((EFI_D_INFO,"VarGetBuffer gCbsSystemConfigurationGuid status is %r\n",Status));
  
  if (StrCmp(BoardExtra,L"CMCC-PC-Setup:01") == 0 ){ //Virtualization
    CbsSetupData->CbsCmnSVMCtrl = 0x01;
    SetupData->SriovSupport = 0x01;
    CbsSetupData->CbsCmnGnbNbIOMMU = 0x01;
  } else if (StrCmp(BoardExtra,L"CMCC-PC-Setup:02") == 0 ){ //Not Virtualization
    CbsSetupData->CbsCmnSVMCtrl = 0x00;
    SetupData->SriovSupport = 0x00;
    CbsSetupData->CbsCmnGnbNbIOMMU = 0x00;
  }
  DEBUG((EFI_D_INFO,"LoadDefaults_CMCC End\n"));
}

EFI_STATUS
CMCCConfigSetupByFru(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS    Status = EFI_SUCCESS;
  EFI_EVENT     EndOfDxeEvent;
  EFI_EVENT     LoadDevDefEvent;
  VOID          *LoadDevDefRegistration;

  Status = gBS->CreateEventEx (
                  EVT_NOTIFY_SIGNAL,
                  TPL_CALLBACK,
                  ConfigSetupByFruNotify,
                  NULL,
                  &gEfiEndOfDxeEventGroupGuid,
                  &EndOfDxeEvent
                  );
  DEBUG((EFI_D_INFO,"ConfigSetupByFruNotify status is %r\n",Status));

  Status = RegisterProtocolCallback(
        &gOemSetupLoadDefaultGuid,
        SetupLoadDefaults,
        NULL, &LoadDevDefEvent, &LoadDevDefRegistration
        );
  DEBUG((EFI_D_INFO,"SetupLoadDefaults status is %r\n",Status));

  return Status;
}
